
import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { AuthProvider } from "./context/AuthContext";
import { AssemblyProvider } from "./context/AssemblyContext";
import Dashboard from "./pages/Dashboard";
import Configurator from "./pages/Configurator";
import Calculator from "./pages/Calculator";
import SavedAssemblies from "./pages/SavedAssemblies";
import Login from "./pages/Login";
import NotFound from "./pages/NotFound";
import PrivateRoute from "./components/auth/PrivateRoute";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <BrowserRouter>
      <AuthProvider>
        <AssemblyProvider>
          <TooltipProvider>
            <Toaster />
            <Sonner />
            <Routes>
              <Route path="/login" element={<Login />} />
              
              <Route path="/" element={<PrivateRoute><Dashboard /></PrivateRoute>} />
              <Route path="/configurator" element={<PrivateRoute><Configurator /></PrivateRoute>} />
              <Route path="/calculator" element={<PrivateRoute><Calculator /></PrivateRoute>} />
              <Route path="/saved-assemblies" element={<PrivateRoute><SavedAssemblies /></PrivateRoute>} />
              
              <Route path="*" element={<NotFound />} />
            </Routes>
          </TooltipProvider>
        </AssemblyProvider>
      </AuthProvider>
    </BrowserRouter>
  </QueryClientProvider>
);

export default App;
