
import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import SystemPriceSummary from '@/components/systemCalculator/SystemPriceSummary';
import FinancialAdjustmentsPanel from '@/components/systemCalculator/FinancialAdjustmentsPanel';
import ProcessCategoryModule from '@/components/systemCalculator/ProcessCategoryModule';
import RatesPanel from '@/components/systemCalculator/RatesPanel';
import TravelCostsTable from '@/components/travelCosts/TravelCostsTable';
import { AssemblyModule, FinancialAdjustments, TravelCost } from '@/types/module';

interface RatesType {
  engineeringRate: number;
  manufacturingRate: number;
  installationRate: number;
  logisticsRate: number;
}

interface CalculatorContentProps {
  modules: AssemblyModule[];
  travelCosts: TravelCost[];
  financialAdjustments: FinancialAdjustments;
  rates: RatesType;
  onUpdateModule: (moduleId: string, updates: Partial<AssemblyModule>) => void;
  onRemoveModule: (moduleId: string) => void;
  onReorderModules: (sourceId: string, targetId: string) => void;
  onAddTravelCost: (cost: TravelCost) => void;
  onUpdateTravelCost: (index: number, cost: Partial<TravelCost>) => void;
  onRemoveTravelCost: (index: number) => void;
  onExport: () => void;
  onExportPdf?: () => void;
  onExportWord?: () => void;
  onFinancialAdjustmentsChange: (adjustments: Partial<FinancialAdjustments>) => void;
  onRatesChange: (rates: Partial<RatesType>) => void;
  onEditConfigurationClick: () => void;
}

const CalculatorContent: React.FC<CalculatorContentProps> = ({
  modules,
  travelCosts,
  financialAdjustments,
  rates,
  onUpdateModule,
  onRemoveModule,
  onReorderModules,
  onAddTravelCost,
  onUpdateTravelCost,
  onRemoveTravelCost,
  onExport,
  onExportPdf,
  onExportWord,
  onFinancialAdjustmentsChange,
  onRatesChange,
  onEditConfigurationClick
}) => {
  // Group modules by process category
  const engineeringModules = modules.filter(m => m.costs.engineering > 0);
  const manufacturingModules = modules.filter(m => m.costs.manufacturing > 0);
  const bomModules = modules.filter(m => m.costs.bom > 0);
  
  // Calculate category totals
  const engineeringTotal = engineeringModules.reduce(
    (sum, module) => sum + (module.costs.engineering * module.quantity), 
    0
  );
  
  const manufacturingTotal = manufacturingModules.reduce(
    (sum, module) => sum + (module.costs.manufacturing * module.quantity), 
    0
  );
  
  const bomTotal = bomModules.reduce(
    (sum, module) => sum + (module.costs.bom * module.quantity), 
    0
  );

  if (modules.length === 0) {
    return (
      <div className="border-2 border-dashed rounded-lg p-12 text-center">
        <h2 className="text-xl font-medium mb-2">No Machine Configuration</h2>
        <p className="text-gray-500 mb-6">
          You need to configure a machine before calculating system prices.
        </p>
        <Button onClick={onEditConfigurationClick}>
          Configure Machine
        </Button>
      </div>
    );
  }

  return (
    <Tabs defaultValue="calculator" className="w-full">
      <TabsList className="w-full grid grid-cols-3 mb-4">
        <TabsTrigger value="calculator">Calculator</TabsTrigger>
        <TabsTrigger value="modules">Module Organization</TabsTrigger>
        <TabsTrigger value="travel">Travel & Installation</TabsTrigger>
      </TabsList>
      
      <TabsContent value="calculator" className="space-y-4">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left Column - Financial Adjustments */}
          <div className="lg:col-span-1 space-y-6">
            <FinancialAdjustmentsPanel 
              adjustments={financialAdjustments}
              onAdjustmentsChange={onFinancialAdjustmentsChange}
            />
            
            <RatesPanel 
              rates={rates} 
              onRatesChange={onRatesChange} 
            />
          </div>
          
          {/* Right Column - Price Summary */}
          <div className="lg:col-span-2 space-y-6">
            <SystemPriceSummary 
              modules={modules}
              travelCosts={travelCosts}
              financialAdjustments={financialAdjustments}
              onExport={onExport}
              onExportPdf={onExportPdf}
              onExportWord={onExportWord}
              hourlyRates={rates}
            />
          </div>
        </div>
      </TabsContent>
      
      <TabsContent value="modules" className="space-y-4">
        <div className="space-y-6">
          <Card>
            <CardHeader className="pb-2 bg-gray-50 border-b">
              <CardTitle className="text-lg">Module Categories</CardTitle>
              <CardDescription>
                Organize modules by type and adjust their parameters
              </CardDescription>
            </CardHeader>
            <CardContent className="pt-6 space-y-8">
              <ProcessCategoryModule
                title="Engineering Modules"
                modules={engineeringModules}
                onUpdateModule={onUpdateModule}
                onRemoveModule={onRemoveModule}
                categoryTotal={engineeringTotal}
                onReorderModules={onReorderModules}
                isDraggable={true}
              />
              
              <ProcessCategoryModule
                title="Manufacturing Modules"
                modules={manufacturingModules}
                onUpdateModule={onUpdateModule}
                onRemoveModule={onRemoveModule}
                categoryTotal={manufacturingTotal}
                onReorderModules={onReorderModules}
                isDraggable={true}
              />
              
              <ProcessCategoryModule
                title="Bill of Materials (BoM)"
                modules={bomModules}
                onUpdateModule={onUpdateModule}
                onRemoveModule={onRemoveModule}
                categoryTotal={bomTotal}
                onReorderModules={onReorderModules}
                isDraggable={true}
              />
            </CardContent>
          </Card>
        </div>
      </TabsContent>
      
      <TabsContent value="travel" className="space-y-4">
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Travel & Installation Costs</CardTitle>
              <CardDescription>Manage your travel and installation expenses</CardDescription>
            </CardHeader>
            <CardContent>
              <TravelCostsTable 
                travelCosts={travelCosts}
                onAddCost={onAddTravelCost}
                onUpdateCost={onUpdateTravelCost}
                onRemoveCost={onRemoveTravelCost}
              />
            </CardContent>
          </Card>
        </div>
      </TabsContent>
    </Tabs>
  );
};

export default CalculatorContent;
