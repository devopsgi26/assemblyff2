
import React from 'react';
import MetadataToggleButton from './buttons/MetadataToggleButton';
import SaveAssemblyButton from './buttons/SaveAssemblyButton';
import EditConfigurationButton from './buttons/EditConfigurationButton';

interface CalculatorToolbarProps {
  isAdminOrManager: boolean;
  metadataVisible: boolean;
  onToggleMetadata: () => void;
  onSaveClick: () => void;
  onEditConfigurationClick: () => void;
}

const CalculatorToolbar: React.FC<CalculatorToolbarProps> = ({
  isAdminOrManager,
  metadataVisible,
  onToggleMetadata,
  onSaveClick,
  onEditConfigurationClick
}) => {
  return (
    <div className="flex items-center justify-between">
      <h1 className="text-2xl font-bold text-gray-900">System Price Calculator</h1>
      <div className="flex space-x-2">
        {isAdminOrManager && (
          <MetadataToggleButton 
            metadataVisible={metadataVisible}
            onClick={onToggleMetadata}
          />
        )}
        <SaveAssemblyButton onClick={onSaveClick} />
        <EditConfigurationButton onClick={onEditConfigurationClick} />
      </div>
    </div>
  );
};

export default CalculatorToolbar;
