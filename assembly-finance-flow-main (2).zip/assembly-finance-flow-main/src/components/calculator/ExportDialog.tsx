
import React from 'react';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription, 
  DialogFooter 
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface ExportDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onExport: () => void;
  isAdminOrManager: boolean;
}

const ExportDialog: React.FC<ExportDialogProps> = ({
  isOpen,
  onOpenChange,
  onExport,
  isAdminOrManager
}) => {
  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Export System Price Summary</DialogTitle>
          <DialogDescription>
            Choose export format and settings
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="flex items-center space-x-2">
            <Input type="checkbox" id="includeBreakdown" className="w-4 h-4" defaultChecked />
            <label htmlFor="includeBreakdown">Include detailed cost breakdown</label>
          </div>
          <div className="flex items-center space-x-2">
            <Input type="checkbox" id="includeModules" className="w-4 h-4" defaultChecked />
            <label htmlFor="includeModules">Include module list</label>
          </div>
          <div className="flex items-center space-x-2">
            <Input 
              type="checkbox" 
              id="includeMetadata" 
              className="w-4 h-4" 
              defaultChecked={isAdminOrManager} 
              disabled={!isAdminOrManager} 
            />
            <label 
              htmlFor="includeMetadata" 
              className={!isAdminOrManager ? "text-gray-400" : ""}
            >
              Include audit metadata (Admin/Manager only)
            </label>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={onExport}>Export</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ExportDialog;
