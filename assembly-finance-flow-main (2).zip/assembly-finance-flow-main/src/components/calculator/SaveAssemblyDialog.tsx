
import React from 'react';
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription, 
  DialogFooter 
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface SaveAssemblyDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  assemblyName: string;
  onAssemblyNameChange: (value: string) => void;
  onSave: () => void;
}

const SaveAssemblyDialog: React.FC<SaveAssemblyDialogProps> = ({
  isOpen,
  onOpenChange,
  assemblyName,
  onAssemblyNameChange,
  onSave
}) => {
  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Save Assembly</DialogTitle>
          <DialogDescription>
            Give your machine assembly a name to save it with the current financial adjustments.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <Input
            placeholder="Assembly Name"
            value={assemblyName}
            onChange={(e) => onAssemblyNameChange(e.target.value)}
          />
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={onSave}>Save</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default SaveAssemblyDialog;
