
import React from 'react';
import { Button } from '@/components/ui/button';

interface EditConfigurationButtonProps {
  onClick: () => void;
}

const EditConfigurationButton: React.FC<EditConfigurationButtonProps> = ({
  onClick
}) => {
  return (
    <Button variant="outline" onClick={onClick}>
      Edit Configuration
    </Button>
  );
};

export default EditConfigurationButton;
