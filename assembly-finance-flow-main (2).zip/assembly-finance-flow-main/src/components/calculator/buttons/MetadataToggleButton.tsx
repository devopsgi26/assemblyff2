
import React from 'react';
import { Button } from '@/components/ui/button';

interface MetadataToggleButtonProps {
  metadataVisible: boolean;
  onClick: () => void;
}

const MetadataToggleButton: React.FC<MetadataToggleButtonProps> = ({
  metadataVisible,
  onClick
}) => {
  return (
    <Button variant="outline" onClick={onClick}>
      {metadataVisible ? 'Hide Metadata' : 'View Metadata'}
    </Button>
  );
};

export default MetadataToggleButton;
