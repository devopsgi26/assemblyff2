
import React from 'react';
import { Button } from '@/components/ui/button';
import { Save } from 'lucide-react';

interface SaveAssemblyButtonProps {
  onClick: () => void;
  showIcon?: boolean;
  variant?: "default" | "destructive" | "outline" | "secondary" | "ghost" | "link";
  size?: "default" | "sm" | "lg" | "icon";
}

const SaveAssemblyButton: React.FC<SaveAssemblyButtonProps> = ({
  onClick,
  showIcon = false,
  variant = "outline",
  size = "default"
}) => {
  return (
    <Button variant={variant} onClick={onClick} size={size}>
      {showIcon && <Save className="w-4 h-4 mr-2" />}
      Save Assembly
    </Button>
  );
};

export default SaveAssemblyButton;
