
import React from 'react';
import { Link } from 'react-router-dom';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg';
}

const Logo: React.FC<LogoProps> = ({ className = '', size = 'md' }) => {
  const sizeClasses = {
    sm: 'h-6',
    md: 'h-8',
    lg: 'h-12'
  };

  return (
    <Link to="/" className={`flex items-center ${className}`}>
      <div className="relative">
        <img 
          src="/lovable-uploads/5b32fd8b-8747-4e77-8d8c-b549a525e682.png" 
          alt="Obducat Logo"
          className={`${sizeClasses[size]} w-auto object-contain`}
        />
      </div>
      <span className="ml-2 font-medium text-gray-800 hidden sm:inline-block">
        Machine Configurator
      </span>
    </Link>
  );
};

export default Logo;
