
import React from 'react';
import { CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { formatCurrency } from '@/utils/rounding';

interface CategoryHeaderProps {
  title: string;
  description?: string;
  totalCost: number;
  expanded: boolean;
  onToggle: () => void;
}

const CategoryHeader: React.FC<CategoryHeaderProps> = ({
  title,
  description,
  totalCost,
  expanded,
  onToggle
}) => {
  return (
    <CardHeader className="cursor-pointer" onClick={onToggle}>
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          {expanded ? <ChevronDown className="h-5 w-5" /> : <ChevronUp className="h-5 w-5" />}
          <CardTitle>{title}</CardTitle>
        </div>
        <div className="text-lg font-semibold text-engineering-primary">
          {formatCurrency(totalCost)}
        </div>
      </div>
      {description && <CardDescription>{description}</CardDescription>}
    </CardHeader>
  );
};

export default CategoryHeader;
