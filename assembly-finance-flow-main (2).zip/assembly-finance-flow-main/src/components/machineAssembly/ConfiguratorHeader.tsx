
import React from 'react';
import { useNavigate } from 'react-router-dom';
import Logo from '@/components/layout/Logo';
import { Button } from '@/components/ui/button';
import SaveAssemblyButton from '@/components/calculator/buttons/SaveAssemblyButton';

interface ConfiguratorHeaderProps {
  onSaveClick: () => void;
}

const ConfiguratorHeader: React.FC<ConfiguratorHeaderProps> = ({ onSaveClick }) => {
  const navigate = useNavigate();

  const handleCalculateClick = () => {
    navigate('/calculator');
  };

  return (
    <div className="flex items-center justify-between">
      <Logo size="lg" />
      <div className="flex space-x-2">
        <SaveAssemblyButton onClick={onSaveClick} showIcon={true} />
        <Button onClick={handleCalculateClick}>
          Calculate Price
        </Button>
      </div>
    </div>
  );
};

export default ConfiguratorHeader;
