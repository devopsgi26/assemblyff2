
import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import MachineSpecsForm from '@/components/machineAssembly/MachineSpecsForm';
import ProcessCategories from '@/components/machineAssembly/ProcessCategories';
import MediaManager from '@/components/media/MediaManager';
import { AssemblyModule, MachineSpecs } from '@/types/module';

interface ConfiguratorTabsProps {
  activeTab: string;
  setActiveTab: (value: string) => void;
  machineSpecs: MachineSpecs;
  updateMachineSpecs: (specs: Partial<MachineSpecs>) => void;
  categories: { id: string; name: string; description: string }[];
  modules: AssemblyModule[];
  availableModules: AssemblyModule[]; // Added missing prop
  getModulesByCategory: (categoryId: string) => AssemblyModule[];
  getAvailableModules: (categoryId: string) => AssemblyModule[];
  onAddModule: (module: AssemblyModule) => void;
  onRemoveModule: (moduleId: string) => void;
  onUpdateQuantity: (moduleId: string, quantity: number) => void;
  onEditModule: (moduleId: string) => void;
  onCreateModule?: (moduleData: Omit<AssemblyModule, 'id'>) => void; // Added missing prop
  onDeleteAvailableModule?: (moduleId: string) => void;
  onReorderModules: (sourceId: string, targetId: string) => void;
}

const ConfiguratorTabs: React.FC<ConfiguratorTabsProps> = ({
  activeTab,
  setActiveTab,
  machineSpecs,
  updateMachineSpecs,
  categories,
  modules,
  availableModules, // Added missing prop
  getModulesByCategory,
  getAvailableModules,
  onAddModule,
  onRemoveModule,
  onUpdateQuantity,
  onEditModule,
  onCreateModule, // Added missing prop
  onDeleteAvailableModule,
  onReorderModules
}) => {
  return (
    <Tabs value={activeTab} onValueChange={setActiveTab}>
      <TabsList className="grid grid-cols-2 w-full">
        <TabsTrigger value="configuration">Machine Configuration</TabsTrigger>
        <TabsTrigger value="media">Media Management</TabsTrigger>
      </TabsList>
      
      <TabsContent value="configuration" className="space-y-6">
        {/* Machine Specs Section */}
        <MachineSpecsForm 
          specs={machineSpecs}
          onSpecsChange={updateMachineSpecs}
        />

        {/* Process Categories */}
        <ProcessCategories 
          categories={categories}
          modules={modules}
          machineSpecs={machineSpecs}
          getModulesByCategory={getModulesByCategory}
          getAvailableModules={getAvailableModules}
          onAddModule={onAddModule}
          onRemoveModule={onRemoveModule}
          onUpdateQuantity={onUpdateQuantity}
          onEditModule={onEditModule}
          onCreateModule={onCreateModule} // Pass the new prop
          onDeleteAvailableModule={onDeleteAvailableModule}
          onReorderModules={onReorderModules}
        />
      </TabsContent>
      
      <TabsContent value="media">
        <MediaManager />
      </TabsContent>
    </Tabs>
  );
};

export default ConfiguratorTabs;
