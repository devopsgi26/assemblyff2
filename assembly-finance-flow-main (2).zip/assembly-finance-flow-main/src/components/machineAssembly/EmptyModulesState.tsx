
import React from 'react';
import { Button } from '@/components/ui/button';

interface EmptyModulesStateProps {
  onBrowseAvailable: () => void;
}

const EmptyModulesState: React.FC<EmptyModulesStateProps> = ({
  onBrowseAvailable
}) => {
  return (
    <div className="border-2 border-dashed rounded-lg p-8 text-center mb-4">
      <p className="text-gray-500 mb-3">
        No modules in this category yet
      </p>
      <Button onClick={onBrowseAvailable} variant="outline" size="sm">
        Browse Available Modules
      </Button>
    </div>
  );
};

export default EmptyModulesState;
