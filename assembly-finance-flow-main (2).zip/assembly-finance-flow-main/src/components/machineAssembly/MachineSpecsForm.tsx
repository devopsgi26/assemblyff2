
import React from 'react';
import { MachineSpecs } from '@/types/module';
import { 
  Card, 
  CardContent, 
  CardHeader, 
  CardTitle, 
  CardDescription 
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Label } from '@/components/ui/label';

interface MachineSpecsFormProps {
  specs: MachineSpecs;
  onSpecsChange: (specs: Partial<MachineSpecs>) => void;
}

const bodyTypeOptions = ['Standard', 'Compact', 'Extended', 'Custom'];
const productLineOptions = ['Alpha', 'Beta', 'Gamma', 'Delta'];
const waferSizeOptions = ['200mm', '300mm', '450mm'];
const axisSetupOptions = ['3-Axis', '4-Axis', '5-Axis', '6-Axis'];

const MachineSpecsForm: React.FC<MachineSpecsFormProps> = ({ specs, onSpecsChange }) => {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Machine Specifications</CardTitle>
        <CardDescription>Configure the base specifications for your machine</CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* Body Type */}
          <div className="space-y-2">
            <Label htmlFor="bodyType">Body Type</Label>
            <Select
              value={specs.bodyType || undefined}
              onValueChange={(value) => onSpecsChange({ bodyType: value })}
            >
              <SelectTrigger id="bodyType">
                <SelectValue placeholder="Select body type" />
              </SelectTrigger>
              <SelectContent>
                {bodyTypeOptions.map((option) => (
                  <SelectItem key={option} value={option}>
                    {option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          {/* Product Line */}
          <div className="space-y-2">
            <Label htmlFor="productLine">Product Line</Label>
            <Select
              value={specs.productLine || undefined}
              onValueChange={(value) => onSpecsChange({ productLine: value })}
            >
              <SelectTrigger id="productLine">
                <SelectValue placeholder="Select product line" />
              </SelectTrigger>
              <SelectContent>
                {productLineOptions.map((option) => (
                  <SelectItem key={option} value={option}>
                    {option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          {/* Wafer Size */}
          <div className="space-y-2">
            <Label htmlFor="waferSize">Wafer Size</Label>
            <Select
              value={specs.waferSize || undefined}
              onValueChange={(value) => onSpecsChange({ waferSize: value })}
            >
              <SelectTrigger id="waferSize">
                <SelectValue placeholder="Select wafer size" />
              </SelectTrigger>
              <SelectContent>
                {waferSizeOptions.map((option) => (
                  <SelectItem key={option} value={option}>
                    {option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          
          {/* Chamber Count */}
          <div className="space-y-2">
            <Label htmlFor="chamberCount">Chamber Count</Label>
            <Input
              id="chamberCount"
              type="number"
              min={1}
              value={specs.chamberCount}
              onChange={(e) => onSpecsChange({ chamberCount: parseInt(e.target.value) || 1 })}
              className="w-full"
            />
          </div>
          
          {/* Axis Setup */}
          <div className="space-y-2">
            <Label htmlFor="axisSetup">Axis Setup</Label>
            <Select
              value={specs.axisSetup || undefined}
              onValueChange={(value) => onSpecsChange({ axisSetup: value })}
            >
              <SelectTrigger id="axisSetup">
                <SelectValue placeholder="Select axis setup" />
              </SelectTrigger>
              <SelectContent>
                {axisSetupOptions.map((option) => (
                  <SelectItem key={option} value={option}>
                    {option}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default MachineSpecsForm;
