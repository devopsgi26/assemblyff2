
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import MediaManager from '@/components/media/MediaManager';

interface MediaSelectorProps {
  currentMedia?: string;
  onSelect: (mediaUrl: string) => void;
  type: 'image' | 'cad';
  className?: string;
}

interface MediaFile {
  id: string;
  name: string;
  type: 'image' | 'cad';
  url: string;
}

const MediaSelector: React.FC<MediaSelectorProps> = ({
  currentMedia,
  onSelect,
  type,
  className = ''
}) => {
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const handleMediaSelected = (media: MediaFile[]) => {
    // Find the first media of the requested type
    const selectedMedia = media.find(m => m.type === type);
    if (selectedMedia) {
      onSelect(selectedMedia.url);
    }
    setIsDialogOpen(false);
  };

  return (
    <>
      <div className={`border rounded-md overflow-hidden ${className}`}>
        {currentMedia ? (
          type === 'image' ? (
            <div className="h-full w-full relative group">
              <img 
                src={currentMedia} 
                alt="Selected media" 
                className="w-full h-full object-cover" 
              />
              <div className="absolute inset-0 bg-black bg-opacity-40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <Button onClick={() => setIsDialogOpen(true)}>
                  Change Image
                </Button>
              </div>
            </div>
          ) : (
            <div className="h-full w-full bg-gray-100 flex items-center justify-center relative group">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
              </svg>
              <div className="absolute inset-0 bg-black bg-opacity-40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <Button onClick={() => setIsDialogOpen(true)}>
                  Change 3D Model
                </Button>
              </div>
            </div>
          )
        ) : (
          <div className="h-full w-full bg-gray-50 flex flex-col items-center justify-center">
            <p className="text-gray-400 mb-2">{type === 'image' ? 'No image selected' : 'No 3D model selected'}</p>
            <Button variant="outline" onClick={() => setIsDialogOpen(true)}>
              Select {type === 'image' ? 'Image' : '3D Model'}
            </Button>
          </div>
        )}
      </div>

      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-4xl max-h-[90vh]">
          <DialogHeader>
            <DialogTitle>Select {type === 'image' ? 'Image' : '3D Model'}</DialogTitle>
          </DialogHeader>
          <div className="overflow-y-auto max-h-[70vh]">
            <MediaManager 
              onMediaChange={handleMediaSelected}
            />
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
};

export default MediaSelector;
