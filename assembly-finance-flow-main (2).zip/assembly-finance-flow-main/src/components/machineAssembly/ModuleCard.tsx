
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { ModuleData, AssemblyModule, MachineSpecs } from '@/types/module';
import { formatCurrency } from '@/utils/rounding';
import { calculateModulePrice } from '@/utils/moduleUtils';
import { useDrag } from 'react-dnd';
import { Edit, MoveVertical, Trash2 } from 'lucide-react';

interface ModuleCardProps {
  module: ModuleData;
  machineSpecs: MachineSpecs;
  quantity?: number;
  onAdd?: (module: AssemblyModule) => void;
  onRemove?: (moduleId: string) => void;
  onUpdateQuantity?: (moduleId: string, quantity: number) => void;
  onEdit?: (moduleId: string) => void;
  onDelete?: () => void;
  isSelected?: boolean;
  showAddButton?: boolean;
  isDraggable?: boolean;
  isCompatible?: boolean;
}

const ModuleCard: React.FC<ModuleCardProps> = ({
  module,
  machineSpecs,
  quantity = 0,
  onAdd,
  onRemove,
  onUpdateQuantity,
  onEdit,
  onDelete,
  isSelected = false,
  showAddButton = true,
  isDraggable = false,
  isCompatible = true,
}) => {
  const totalCost = calculateModulePrice(module as AssemblyModule);

  const handleAddClick = () => {
    if (onAdd) {
      onAdd({ ...module, quantity: 1 } as AssemblyModule);
    }
  };

  const handleRemoveClick = () => {
    if (onRemove) {
      onRemove(module.id);
    }
  };

  const handleDeleteClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onDelete) {
      onDelete();
    }
  };

  const incrementQuantity = () => {
    if (onUpdateQuantity) {
      onUpdateQuantity(module.id, quantity + 1);
    }
  };

  const decrementQuantity = () => {
    if (onUpdateQuantity && quantity > 1) {
      onUpdateQuantity(module.id, quantity - 1);
    } else if (onRemove && quantity === 1) {
      onRemove(module.id);
    }
  };

  const handleEditClick = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (onEdit) {
      onEdit(module.id);
    }
  };

  const [{ isDragging }, drag] = useDrag(() => ({
    type: 'MODULE',
    item: { id: module.id },
    collect: (monitor) => ({
      isDragging: !!monitor.isDragging(),
    }),
    canDrag: isDraggable,
  }));

  return (
    <Card 
      ref={isDraggable ? drag : undefined}
      className={`transition-all duration-200 ${
        isSelected ? 'border-engineering-primary shadow-md' : ''
      } ${
        !isCompatible ? 'opacity-60' : ''
      } ${
        isDragging ? 'opacity-30' : ''
      } ${
        isDraggable ? 'cursor-move' : ''
      }`}
    >
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <div className="flex items-center gap-1">
            {isDraggable && (
              <MoveVertical className="h-4 w-4 text-gray-400" />
            )}
            <CardTitle className="text-lg">{module.name}</CardTitle>
          </div>
          <div className="flex gap-1">
            {!isCompatible && (
              <Badge variant="destructive" className="text-xs">Incompatible</Badge>
            )}
            {isCompatible && isSelected && (
              <Badge variant="default" className="bg-engineering-primary text-xs">Selected</Badge>
            )}
            {onEdit && (
              <Button size="sm" variant="ghost" className="h-6 w-6 p-0" onClick={handleEditClick}>
                <Edit className="h-4 w-4" />
              </Button>
            )}
            {onDelete && !isSelected && (
              <Button size="sm" variant="ghost" className="h-6 w-6 p-0 text-red-500" onClick={handleDeleteClick}>
                <Trash2 className="h-4 w-4" />
              </Button>
            )}
          </div>
        </div>
        <CardDescription>{module.description}</CardDescription>
      </CardHeader>
      
      <CardContent className="space-y-3 py-2">
        {/* Module Image */}
        {module.media.imageUrl ? (
          <div className="h-32 w-full bg-gray-100 rounded overflow-hidden">
            <img
              src={module.media.imageUrl}
              alt={module.name}
              className="w-full h-full object-cover"
            />
          </div>
        ) : (
          <div className="h-32 w-full bg-gray-100 rounded flex items-center justify-center text-gray-400">
            No image available
          </div>
        )}
        
        {/* Cost Breakdown */}
        <div className="space-y-1 text-sm">
          <div className="flex justify-between">
            <span className="text-gray-500">Base Price:</span>
            <span className="font-medium">{formatCurrency(module.basePrice || 0)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-500">Engineering:</span>
            <span className="font-medium">{formatCurrency(module.costs.engineering)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-500">Manufacturing:</span>
            <span className="font-medium">{formatCurrency(module.costs.manufacturing)}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-500">BOM:</span>
            <span className="font-medium">{formatCurrency(module.costs.bom)}</span>
          </div>
          <div className="flex justify-between pt-1 border-t">
            <span className="text-gray-700 font-medium">Total:</span>
            <span className="font-bold text-engineering-primary">{formatCurrency(totalCost)}</span>
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="pt-0">
        {!isSelected && showAddButton && (
          <Button 
            onClick={handleAddClick} 
            className="w-full"
            disabled={!isCompatible}
          >
            Add to Machine
          </Button>
        )}
        
        {isSelected && (
          <div className="flex w-full justify-between items-center">
            <Button variant="outline" size="icon" onClick={decrementQuantity}>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
              </svg>
            </Button>
            <span className="font-medium px-4">{quantity}</span>
            <Button variant="outline" size="icon" onClick={incrementQuantity}>
              <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
              </svg>
            </Button>
            <Button variant="destructive" size="sm" className="ml-2" onClick={handleRemoveClick}>
              Remove
            </Button>
          </div>
        )}
      </CardFooter>
    </Card>
  );
};

export default ModuleCard;
