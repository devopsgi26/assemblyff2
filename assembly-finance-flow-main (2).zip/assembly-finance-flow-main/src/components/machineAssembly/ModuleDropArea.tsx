
import React, { ReactNode } from 'react';
import { useDrop } from 'react-dnd';

interface ModuleDropAreaProps {
  moduleId: string;
  children: ReactNode;
  onDrop: (sourceId: string, targetId: string) => void;
}

const ModuleDropArea: React.FC<ModuleDropAreaProps> = ({ 
  moduleId, 
  children, 
  onDrop 
}) => {
  const [{ isOver }, drop] = useDrop(() => ({
    accept: 'MODULE',
    drop: (item: { id: string }) => {
      if (item.id !== moduleId) {
        onDrop(item.id, moduleId);
      }
    },
    collect: (monitor) => ({
      isOver: !!monitor.isOver() && monitor.getItem()?.id !== moduleId,
    }),
  }));

  return (
    <div 
      ref={drop} 
      className={`relative ${isOver ? 'ring-2 ring-engineering-primary' : ''} transition-all duration-200`}
      data-module-id={moduleId}
    >
      {isOver && (
        <div className="absolute inset-0 bg-engineering-primary bg-opacity-10 pointer-events-none z-10 flex items-center justify-center">
          <div className="bg-white px-2 py-1 rounded-md text-sm shadow-sm">
            Drop here to reorder
          </div>
        </div>
      )}
      {children}
    </div>
  );
};

export default ModuleDropArea;
