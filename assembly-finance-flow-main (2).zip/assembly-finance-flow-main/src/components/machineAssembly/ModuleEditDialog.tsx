
import React, { useState, useEffect } from 'react';
import { 
  Dialog,
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription, 
  DialogFooter 
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { AssemblyModule } from '@/types/module';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import ModuleBasicDetailsTab from './dialog/ModuleBasicDetailsTab';
import ModuleCostsTab from './dialog/ModuleCostsTab';
import ModuleMediaTab from './dialog/ModuleMediaTab';
import ModuleCompatibilityTab from './dialog/ModuleCompatibilityTab';
import { mockModules } from '@/data/mockModules';

interface ModuleEditDialogProps {
  module: AssemblyModule | null;
  isOpen: boolean;
  onClose: () => void;
  onSave: (updatedModule: AssemblyModule) => void;
  availableModules?: AssemblyModule[]; // For compatibility selection
}

const ModuleEditDialog: React.FC<ModuleEditDialogProps> = ({
  module,
  isOpen,
  onClose,
  onSave,
  availableModules = []
}) => {
  const [editedModule, setEditedModule] = useState<AssemblyModule | null>(null);
  const [activeTab, setActiveTab] = useState('details');

  // Reset edited module when the input module changes
  useEffect(() => {
    if (module) {
      // Create a deep copy to avoid mutating the original module
      setEditedModule(JSON.parse(JSON.stringify(module)));
    } else {
      setEditedModule(null);
    }
  }, [module]);

  const handleChange = (field: string, value: any) => {
    if (!editedModule) return;

    // Handle nested properties using dot notation
    if (field.includes('.')) {
      const [parent, child] = field.split('.');
      if (parent === 'costs') {
        setEditedModule({
          ...editedModule,
          costs: {
            ...editedModule.costs,
            [child]: value
          }
        });
      } else if (parent === 'media') {
        setEditedModule({
          ...editedModule,
          media: {
            ...editedModule.media,
            [child]: value
          }
        });
      } else if (parent === 'compatibility') {
        setEditedModule({
          ...editedModule,
          compatibility: {
            ...editedModule.compatibility,
            [child]: value
          }
        });
      }
    } else {
      setEditedModule({
        ...editedModule,
        [field]: value
      } as AssemblyModule);
    }
  };

  const handleSave = () => {
    if (editedModule) {
      onSave(editedModule);
    }
    onClose();
  };

  // Combine current modules with mock modules for compatibility selection
  const allModules = [...availableModules];
  
  // Add any mock modules that aren't already in the list
  mockModules.forEach(mockModule => {
    if (!allModules.some(m => m.id === mockModule.id)) {
      allModules.push({...mockModule, quantity: 1});
    }
  });

  if (!editedModule) return null;

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Edit Module</DialogTitle>
          <DialogDescription>
            Update the details, costs, and compatibility for this module
          </DialogDescription>
        </DialogHeader>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid grid-cols-4 mb-4">
            <TabsTrigger value="details">Basic Details</TabsTrigger>
            <TabsTrigger value="costs">Costs & BOM</TabsTrigger>
            <TabsTrigger value="compatibility">Compatibility</TabsTrigger>
            <TabsTrigger value="media">Media & Files</TabsTrigger>
          </TabsList>
          
          <TabsContent value="details" className="space-y-4">
            <ModuleBasicDetailsTab 
              module={editedModule} 
              onChange={handleChange} 
            />
          </TabsContent>
          
          <TabsContent value="costs" className="space-y-4">
            <ModuleCostsTab 
              module={editedModule} 
              onChange={handleChange} 
            />
          </TabsContent>
          
          <TabsContent value="compatibility" className="space-y-4">
            <ModuleCompatibilityTab
              module={editedModule}
              onChange={handleChange}
              availableModules={allModules.filter(m => m.id !== editedModule.id)}
            />
          </TabsContent>
          
          <TabsContent value="media" className="space-y-4">
            <ModuleMediaTab 
              module={editedModule} 
              onChange={handleChange} 
            />
          </TabsContent>
        </Tabs>

        <DialogFooter>
          <Button variant="outline" onClick={onClose}>Cancel</Button>
          <Button onClick={handleSave}>Save Changes</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default ModuleEditDialog;
