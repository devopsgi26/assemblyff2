
import React from 'react';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import ModuleCard from './ModuleCard';
import ModuleDropArea from './ModuleDropArea';
import { AssemblyModule, MachineSpecs } from '@/types/module';
import { checkModuleCompatibility } from '@/utils/moduleUtils';

interface ModuleLibraryProps {
  availableModules: AssemblyModule[];
  selectedModules: AssemblyModule[];
  machineSpecs: MachineSpecs;
  showAvailable: boolean;
  onToggleAvailable: () => void;
  onCreateModule?: () => void;
  onAddModule: (module: AssemblyModule) => void;
  onEditModule?: (moduleId: string) => void;
  onDeleteModule?: (moduleId: string) => void;
  onReorderModules?: (sourceId: string, targetId: string) => void;
}

const ModuleLibrary: React.FC<ModuleLibraryProps> = ({
  availableModules,
  selectedModules,
  machineSpecs,
  showAvailable,
  onToggleAvailable,
  onCreateModule,
  onAddModule,
  onEditModule,
  onDeleteModule,
  onReorderModules
}) => {
  const isModuleCompatible = (module: AssemblyModule): boolean => {
    return checkModuleCompatibility(module, selectedModules);
  };

  return (
    <div className="border-t mt-4 pt-4">
      <div className="flex justify-between items-center mb-4">
        <h3 className="font-medium text-sm">Module Library</h3>
        <div className="flex gap-2">
          <Button 
            onClick={onCreateModule} 
            variant="outline" 
            size="sm"
            disabled={!onCreateModule}
          >
            <Plus className="mr-1 h-4 w-4" /> Create New Module
          </Button>
          <Button onClick={onToggleAvailable} variant="ghost" size="sm">
            {showAvailable ? 'Hide' : 'Show'} Available Modules
          </Button>
        </div>
      </div>
      
      {showAvailable && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {availableModules.length > 0 ? (
            availableModules.map((module) => (
              <ModuleDropArea
                key={module.id}
                moduleId={module.id}
                onDrop={(sourceId, targetId) => {
                  if (onReorderModules && sourceId !== targetId) {
                    onReorderModules(sourceId, targetId);
                  }
                }}
              >
                <ModuleCard
                  key={module.id}
                  module={module}
                  machineSpecs={machineSpecs}
                  onAdd={onAddModule}
                  onEdit={onEditModule}
                  onDelete={onDeleteModule ? () => onDeleteModule(module.id) : undefined}
                  isCompatible={isModuleCompatible(module)}
                  isDraggable={true}
                />
              </ModuleDropArea>
            ))
          ) : (
            <div className="col-span-full text-center p-4 text-gray-500">
              No more modules available for this category
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default ModuleLibrary;
