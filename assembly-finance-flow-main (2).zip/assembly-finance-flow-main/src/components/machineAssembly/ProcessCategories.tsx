
import React from 'react';
import ProcessCategory from './ProcessCategory';
import { AssemblyModule, MachineSpecs } from '@/types/module';

interface ProcessCategoriesProps {
  categories: { id: string; name: string; description: string }[];
  modules: AssemblyModule[];
  machineSpecs: MachineSpecs;
  getModulesByCategory: (categoryId: string) => AssemblyModule[];
  getAvailableModules: (categoryId: string) => AssemblyModule[];
  onAddModule: (module: AssemblyModule) => void;
  onRemoveModule: (moduleId: string) => void;
  onUpdateQuantity: (moduleId: string, quantity: number) => void;
  onEditModule: (moduleId: string) => void;
  onCreateModule?: (moduleData: Omit<AssemblyModule, 'id'>) => void; // Added this prop
  onDeleteAvailableModule?: (moduleId: string) => void;
  onReorderModules: (sourceId: string, targetId: string) => void;
}

const ProcessCategories: React.FC<ProcessCategoriesProps> = ({
  categories,
  modules,
  machineSpecs,
  getModulesByCategory,
  getAvailableModules,
  onAddModule,
  onRemoveModule,
  onUpdateQuantity,
  onEditModule,
  onCreateModule, // Added this prop
  onDeleteAvailableModule,
  onReorderModules
}) => {
  return (
    <>
      {categories.map(category => (
        <ProcessCategory
          key={category.id}
          title={category.name}
          description={category.description}
          modules={getModulesByCategory(category.id)}
          availableModules={getAvailableModules(category.id)}
          machineSpecs={machineSpecs}
          onAddModule={onAddModule}
          onRemoveModule={onRemoveModule}
          onUpdateQuantity={onUpdateQuantity}
          onReorderModules={onReorderModules}
          onEditModule={onEditModule}
          onCreateModule={onCreateModule} // Pass the new prop
          onDeleteAvailableModule={onDeleteAvailableModule}
        />
      ))}
    </>
  );
};

export default ProcessCategories;
