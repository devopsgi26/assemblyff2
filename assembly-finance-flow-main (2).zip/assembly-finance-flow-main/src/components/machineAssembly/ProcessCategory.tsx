
import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { AssemblyModule, MachineSpecs } from '@/types/module';
import { calculateModulePrice } from '@/utils/moduleUtils';
import { useToast } from '@/hooks/use-toast';
import CategoryHeader from './CategoryHeader';
import EmptyModulesState from './EmptyModulesState';
import SelectedModulesGrid from './SelectedModulesGrid';
import ModuleLibrary from './ModuleLibrary';
import DeleteModuleDialog from './DeleteModuleDialog';

interface ProcessCategoryProps {
  title: string;
  description?: string;
  modules: AssemblyModule[];
  availableModules: AssemblyModule[];
  machineSpecs: MachineSpecs;
  onAddModule: (module: AssemblyModule) => void;
  onRemoveModule: (moduleId: string) => void;
  onUpdateQuantity: (moduleId: string, quantity: number) => void;
  onReorderModules?: (sourceId: string, targetId: string) => void;
  onEditModule?: (moduleId: string) => void;
  onCreateModule?: (moduleData: Omit<AssemblyModule, 'id'>) => void; 
  onDeleteAvailableModule?: (moduleId: string) => void;
}

const ProcessCategory: React.FC<ProcessCategoryProps> = ({
  title,
  description,
  modules,
  availableModules,
  machineSpecs,
  onAddModule,
  onRemoveModule,
  onUpdateQuantity,
  onReorderModules,
  onEditModule,
  onCreateModule,
  onDeleteAvailableModule
}) => {
  const [expanded, setExpanded] = useState(true);
  const [showAvailable, setShowAvailable] = useState(false);
  const [moduleToDelete, setModuleToDelete] = useState<string | null>(null);
  const { toast } = useToast();

  // Calculate total cost for this category including base prices with financial precision
  const totalCost = Math.round(modules.reduce((sum, module) => {
    return sum + (calculateModulePrice(module) * module.quantity);
  }, 0) * 100) / 100;

  const handleCreateNewModule = () => {
    if (!onCreateModule) return;
    
    // Create a new empty module with default values
    const newModule: Omit<AssemblyModule, 'id'> = {
      name: `New ${title} Module`,
      description: `A new custom module for ${title}`,
      quantity: 1,
      basePrice: 0,
      costs: {
        engineering: 0,
        manufacturing: 0,
        bom: 0
      },
      compatibility: {
        compatibleModules: [],
        incompatibleModules: []
      },
      media: {
        imageUrl: '',
        cadModelUrl: ''
      }
    };
    
    onCreateModule(newModule);
  };

  const handleDeleteRequest = (moduleId: string) => {
    setModuleToDelete(moduleId);
  };

  const handleDeleteConfirm = () => {
    if (moduleToDelete && onDeleteAvailableModule) {
      try {
        // Check if module is currently in use in any category
        const moduleInUse = modules.some(m => m.id === moduleToDelete);
        if (moduleInUse) {
          toast({
            title: 'Cannot Delete Module',
            description: 'This module is currently in use. Remove it from the assembly first.',
            variant: 'destructive',
          });
          setModuleToDelete(null);
          return;
        }

        onDeleteAvailableModule(moduleToDelete);
        toast({
          title: 'Module Deleted',
          description: 'Module has been permanently removed from the library.',
        });
      } catch (error) {
        console.error('Delete module error:', error);
        toast({
          title: 'Delete Failed',
          description: 'Failed to delete module. Please try again.',
          variant: 'destructive',
        });
      }
    }
    setModuleToDelete(null);
  };

  return (
    <Card className="mb-6">
      <CategoryHeader
        title={title}
        description={description}
        totalCost={totalCost}
        expanded={expanded}
        onToggle={() => setExpanded(!expanded)}
      />
      
      {expanded && (
        <CardContent className="pt-0">
          {modules.length === 0 ? (
            <EmptyModulesState onBrowseAvailable={() => setShowAvailable(!showAvailable)} />
          ) : (
            <SelectedModulesGrid
              modules={modules}
              machineSpecs={machineSpecs}
              onRemoveModule={onRemoveModule}
              onUpdateQuantity={onUpdateQuantity}
              onEditModule={onEditModule}
              onReorderModules={onReorderModules}
            />
          )}
          
          <ModuleLibrary
            availableModules={availableModules}
            selectedModules={modules}
            machineSpecs={machineSpecs}
            showAvailable={showAvailable}
            onToggleAvailable={() => setShowAvailable(!showAvailable)}
            onCreateModule={onCreateModule ? handleCreateNewModule : undefined}
            onAddModule={onAddModule}
            onEditModule={onEditModule}
            onDeleteModule={onDeleteAvailableModule ? handleDeleteRequest : undefined}
            onReorderModules={onReorderModules}
          />
        </CardContent>
      )}

      <DeleteModuleDialog
        isOpen={!!moduleToDelete}
        onClose={() => setModuleToDelete(null)}
        onConfirm={handleDeleteConfirm}
      />
    </Card>
  );
};

export default ProcessCategory;
