
import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/components/ui/use-toast';

interface SaveAssemblyDialogProps {
  isOpen: boolean;
  onOpenChange: (open: boolean) => void;
  onSave: (name: string) => void;
}

const SaveAssemblyDialog: React.FC<SaveAssemblyDialogProps> = ({ 
  isOpen, 
  onOpenChange, 
  onSave 
}) => {
  const [assemblyName, setAssemblyName] = useState('');
  const { toast } = useToast();

  const handleSaveClick = () => {
    if (!assemblyName.trim()) {
      toast({
        title: 'Name Required',
        description: 'Please enter a name for your assembly.',
        variant: 'destructive',
      });
      return;
    }
    
    onSave(assemblyName);
    setAssemblyName('');
    onOpenChange(false);
  };

  return (
    <Dialog open={isOpen} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>Save Assembly</DialogTitle>
          <DialogDescription>
            Give your machine assembly a name to save it for future reference.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <Input
            placeholder="Assembly Name"
            value={assemblyName}
            onChange={(e) => setAssemblyName(e.target.value)}
          />
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Cancel
          </Button>
          <Button onClick={handleSaveClick}>Save</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};

export default SaveAssemblyDialog;
