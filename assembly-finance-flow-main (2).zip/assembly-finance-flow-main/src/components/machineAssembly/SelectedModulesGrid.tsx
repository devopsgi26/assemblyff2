
import React from 'react';
import ModuleCard from './ModuleCard';
import ModuleDropArea from './ModuleDropArea';
import { AssemblyModule, MachineSpecs } from '@/types/module';

interface SelectedModulesGridProps {
  modules: AssemblyModule[];
  machineSpecs: MachineSpecs;
  onRemoveModule: (moduleId: string) => void;
  onUpdateQuantity: (moduleId: string, quantity: number) => void;
  onEditModule?: (moduleId: string) => void;
  onReorderModules?: (sourceId: string, targetId: string) => void;
}

const SelectedModulesGrid: React.FC<SelectedModulesGridProps> = ({
  modules,
  machineSpecs,
  onRemoveModule,
  onUpdateQuantity,
  onEditModule,
  onReorderModules
}) => {
  return (
    <div className="mb-4">
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {modules.map((module) => (
          <ModuleDropArea 
            key={module.id}
            moduleId={module.id}
            onDrop={onReorderModules ? onReorderModules : () => {}}
          >
            <ModuleCard
              module={module}
              machineSpecs={machineSpecs}
              quantity={module.quantity}
              onRemove={onRemoveModule}
              onUpdateQuantity={onUpdateQuantity}
              onEdit={onEditModule}
              isSelected={true}
              showAddButton={false}
              isDraggable={!!onReorderModules}
            />
          </ModuleDropArea>
        ))}
      </div>
    </div>
  );
};

export default SelectedModulesGrid;
