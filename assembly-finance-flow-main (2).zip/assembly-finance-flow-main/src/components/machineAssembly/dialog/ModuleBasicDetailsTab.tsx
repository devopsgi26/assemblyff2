
import React from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { AssemblyModule } from '@/types/module';

interface ModuleBasicDetailsTabProps {
  module: AssemblyModule;
  onChange: (field: string, value: any) => void;
}

const ModuleBasicDetailsTab: React.FC<ModuleBasicDetailsTabProps> = ({
  module,
  onChange
}) => {
  return (
    <div className="space-y-4">
      <div>
        <Label htmlFor="name">Module Name</Label>
        <Input
          id="name"
          value={module.name}
          onChange={(e) => onChange('name', e.target.value)}
        />
      </div>
      
      <div>
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={module.description}
          onChange={(e) => onChange('description', e.target.value)}
          className="min-h-[100px]"
        />
      </div>

      <div>
        <Label htmlFor="quantity">Quantity</Label>
        <Input
          id="quantity"
          type="number"
          min={1}
          value={module.quantity}
          onChange={(e) => onChange('quantity', parseInt(e.target.value) || 1)}
        />
      </div>
    </div>
  );
};

export default ModuleBasicDetailsTab;
