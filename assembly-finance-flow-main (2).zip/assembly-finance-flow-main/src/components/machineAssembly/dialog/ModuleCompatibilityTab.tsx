import React from 'react';
import { AssemblyModule } from '@/types/module';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent } from '@/components/ui/card';

interface ModuleCompatibilityTabProps {
  module: AssemblyModule;
  onChange: (field: string, value: any) => void;
  availableModules?: AssemblyModule[];
}

const ModuleCompatibilityTab: React.FC<ModuleCompatibilityTabProps> = ({ 
  module, 
  onChange,
  availableModules = [] 
}) => {
  const toggleModuleCompatibility = (moduleId: string) => {
    const incompatibleModules = module.compatibility?.incompatibleModules || [];
    
    // If it's in incompatible list, remove it (making it compatible)
    if (incompatibleModules.includes(moduleId)) {
      onChange('compatibility.incompatibleModules', incompatibleModules.filter(id => id !== moduleId));
    } 
    // Otherwise add to incompatible list
    else {
      onChange('compatibility.incompatibleModules', [...incompatibleModules, moduleId]);
    }
  };

  const isModuleIncompatible = (moduleId: string) => {
    const incompatibleModules = module.compatibility?.incompatibleModules || [];
    return incompatibleModules.includes(moduleId);
  };

  return (
    <Card>
      <CardContent className="space-y-6 pt-6">
        <div className="space-y-2">
          <Label>Module Compatibility</Label>
          <p className="text-sm text-gray-500 mb-3">
            Set which modules are compatible or incompatible with this module. Click to toggle between Compatible and Not Compatible.
          </p>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {availableModules
              .filter(m => m.id !== module.id)
              .map(otherModule => {
                const isIncompatible = isModuleIncompatible(otherModule.id);
                return (
                  <div 
                    key={otherModule.id} 
                    className={`p-3 border rounded-md cursor-pointer transition-colors ${
                      isIncompatible ? 'border-red-500 bg-red-50' : 'border-green-500 bg-green-50'
                    }`}
                    onClick={() => toggleModuleCompatibility(otherModule.id)}
                  >
                    <div className="flex items-center justify-between">
                      <span className="font-medium">{otherModule.name}</span>
                      <Badge variant={isIncompatible ? 'destructive' : 'default'}>
                        {isIncompatible ? 'Not Compatible' : 'Compatible'}
                      </Badge>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ModuleCompatibilityTab;
