
import React from 'react';
import { AssemblyModule } from '@/types/module';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent } from '@/components/ui/card';
import { formatCurrency } from '@/utils/rounding';

interface ModuleCostsTabProps {
  module: AssemblyModule;
  onChange: (field: string, value: any) => void;
}

const ModuleCostsTab: React.FC<ModuleCostsTabProps> = ({ module, onChange }) => {
  // Use hourly rates from the app's configuration
  const engineeringRate = 85; // Default hourly rate for engineering
  const manufacturingRate = 65; // Default hourly rate for manufacturing

  const handleBasePriceChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value) || 0;
    onChange('basePrice', value);
  };

  const handleEngineeringHoursChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const hours = parseFloat(e.target.value) || 0;
    const cost = Math.round(hours * engineeringRate * 100) / 100; // Financial-grade precision
    onChange('costs.engineering', cost);
  };

  const handleManufacturingHoursChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const hours = parseFloat(e.target.value) || 0;
    const cost = Math.round(hours * manufacturingRate * 100) / 100; // Financial-grade precision
    onChange('costs.manufacturing', cost);
  };

  const handleDirectCostChange = (field: string, e: React.ChangeEvent<HTMLInputElement>) => {
    const value = Math.round(parseFloat(e.target.value) * 100) / 100 || 0; // Financial-grade precision
    onChange(`costs.${field}`, value);
  };

  // Calculate engineering and manufacturing hours from costs with precision
  const engineeringHours = Math.round((module.costs.engineering / engineeringRate) * 100) / 100;
  const manufacturingHours = Math.round((module.costs.manufacturing / manufacturingRate) * 100) / 100;

  // Calculate total cost including base price with financial precision
  const totalCost = Math.round(((module.basePrice || 0) + module.costs.engineering + module.costs.manufacturing + module.costs.bom) * 100) / 100;

  return (
    <Card>
      <CardContent className="space-y-6 pt-6">
        {/* Base Price Section */}
        <div>
          <Label htmlFor="basePrice">Base Price</Label>
          <div className="flex items-center gap-2 mt-1">
            <Input
              id="basePrice"
              type="number"
              min="0"
              step="0.01"
              value={module.basePrice || 0}
              onChange={handleBasePriceChange}
              className="flex-1"
            />
            <span className="text-sm text-gray-500">€</span>
          </div>
          <p className="text-xs text-gray-500 mt-1">Base module cost before labor and materials</p>
        </div>

        {/* Engineering Section */}
        <div className="space-y-4">
          <div>
            <Label htmlFor="engineeringHours">Engineering Hours</Label>
            <div className="flex items-center gap-2 mt-1">
              <Input
                id="engineeringHours"
                type="number"
                min="0"
                step="0.01"
                value={engineeringHours.toFixed(2)}
                onChange={handleEngineeringHoursChange}
                className="flex-1"
              />
              <span className="text-sm text-gray-500">hours</span>
            </div>
          </div>

          <div>
            <Label htmlFor="engineeringCost">Engineering Cost</Label>
            <div className="flex items-center gap-2 mt-1">
              <Input
                id="engineeringCost"
                type="number"
                min="0"
                step="0.01"
                value={module.costs.engineering.toFixed(2)}
                onChange={(e) => handleDirectCostChange('engineering', e)}
                className="flex-1"
              />
              <span className="text-sm text-gray-500">€</span>
            </div>
            <p className="text-xs text-gray-500 mt-1">Rate: €{engineeringRate}/hr</p>
          </div>
        </div>

        {/* Manufacturing Section */}
        <div className="space-y-4">
          <div>
            <Label htmlFor="manufacturingHours">Manufacturing Hours</Label>
            <div className="flex items-center gap-2 mt-1">
              <Input
                id="manufacturingHours"
                type="number"
                min="0"
                step="0.01"
                value={manufacturingHours.toFixed(2)}
                onChange={handleManufacturingHoursChange}
                className="flex-1"
              />
              <span className="text-sm text-gray-500">hours</span>
            </div>
          </div>

          <div>
            <Label htmlFor="manufacturingCost">Manufacturing Cost</Label>
            <div className="flex items-center gap-2 mt-1">
              <Input
                id="manufacturingCost"
                type="number"
                min="0"
                step="0.01"
                value={module.costs.manufacturing.toFixed(2)}
                onChange={(e) => handleDirectCostChange('manufacturing', e)}
                className="flex-1"
              />
              <span className="text-sm text-gray-500">€</span>
            </div>
            <p className="text-xs text-gray-500 mt-1">Rate: €{manufacturingRate}/hr</p>
          </div>
        </div>

        {/* BOM Cost Section */}
        <div>
          <Label htmlFor="bomCost">Bill of Materials Cost</Label>
          <div className="flex items-center gap-2 mt-1">
            <Input
              id="bomCost"
              type="number"
              min="0"
              step="0.01"
              value={module.costs.bom.toFixed(2)}
              onChange={(e) => handleDirectCostChange('bom', e)}
              className="flex-1"
            />
            <span className="text-sm text-gray-500">€</span>
          </div>
        </div>

        {/* Total Cost Display */}
        <div className="pt-4 border-t border-gray-200">
          <div className="space-y-2">
            <div className="flex justify-between">
              <span className="text-sm text-gray-500">Base Price:</span>
              <span className="font-medium">{formatCurrency(module.basePrice || 0)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-sm text-gray-500">Labor & Materials:</span>
              <span className="font-medium">{formatCurrency(module.costs.engineering + module.costs.manufacturing + module.costs.bom)}</span>
            </div>
            <div className="flex justify-between pt-2 border-t">
              <span className="font-medium">Total Module Cost:</span>
              <span className="font-bold text-engineering-primary">{formatCurrency(totalCost)}</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default ModuleCostsTab;
