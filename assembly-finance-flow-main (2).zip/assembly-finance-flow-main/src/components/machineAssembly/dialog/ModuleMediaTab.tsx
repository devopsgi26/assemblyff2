
import React from 'react';
import { Label } from '@/components/ui/label';
import { AssemblyModule } from '@/types/module';
import MediaSelector from '../MediaSelector';

interface ModuleMediaTabProps {
  module: AssemblyModule;
  onChange: (field: string, value: any) => void;
}

const ModuleMediaTab: React.FC<ModuleMediaTabProps> = ({
  module,
  onChange
}) => {
  const handleImageSelect = (imageUrl: string) => {
    onChange('media.imageUrl', imageUrl);
  };

  const handleCADModelSelect = (cadModelUrl: string) => {
    onChange('media.cadModelUrl', cadModelUrl);
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
      <div>
        <Label className="block mb-2">Module Image</Label>
        <MediaSelector
          currentMedia={module.media?.imageUrl || ''}
          onSelect={handleImageSelect}
          type="image"
          className="h-48"
        />
      </div>
      
      <div>
        <Label className="block mb-2">CAD Model</Label>
        <MediaSelector
          currentMedia={module.media?.cadModelUrl || ''}
          onSelect={handleCADModelSelect}
          type="cad"
          className="h-48"
        />
      </div>
    </div>
  );
};

export default ModuleMediaTab;
