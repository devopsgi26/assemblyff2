import React, { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useAuth } from '@/context/AuthContext';
import { validateImageFile, validateCADFile, createLocalFileUrl } from '@/utils/mediaUtils';
import { useToast } from '@/components/ui/use-toast';

interface MediaFile {
  id: string;
  name: string;
  type: 'image' | 'cad';
  url: string;
}

interface MediaManagerProps {
  initialMedia?: MediaFile[];
  onMediaChange?: (media: MediaFile[]) => void;
}

const MediaManager: React.FC<MediaManagerProps> = ({
  initialMedia = [],
  onMediaChange,
}) => {
  const [media, setMedia] = useState<MediaFile[]>(initialMedia);
  const [previewFile, setPreviewFile] = useState<MediaFile | null>(null);
  const { hasPermission } = useAuth();
  const canUpload = hasPermission('uploadMedia');
  const imageInputRef = useRef<HTMLInputElement>(null);
  const cadInputRef = useRef<HTMLInputElement>(null);
  const { toast } = useToast();

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>, type: 'image' | 'cad') => {
    if (!event.target.files || event.target.files.length === 0) {
      return;
    }

    const file = event.target.files[0];
    let isValid = false;

    if (type === 'image') {
      isValid = validateImageFile(file);
      if (!isValid) {
        toast({
          title: 'Invalid Image',
          description: 'Please upload a valid image (JPG, PNG, GIF) under 5MB.',
          variant: 'destructive',
        });
        return;
      }
    } else {
      isValid = validateCADFile(file);
      if (!isValid) {
        toast({
          title: 'Invalid CAD File',
          description: 'Please upload a valid 3D model file under 20MB.',
          variant: 'destructive',
        });
        return;
      }
    }

    const url = createLocalFileUrl(file);
    const newFile: MediaFile = {
      id: `media-${Date.now()}`,
      name: file.name,
      type,
      url,
    };

    const updatedMedia = [...media, newFile];
    setMedia(updatedMedia);
    
    if (onMediaChange) {
      onMediaChange(updatedMedia);
    }

    toast({
      title: 'Media Uploaded',
      description: `${file.name} has been added to your media library.`,
    });

    // Reset the input
    event.target.value = '';
  };

  const handleRemoveMedia = (id: string) => {
    const updatedMedia = media.filter(item => item.id !== id);
    setMedia(updatedMedia);
    
    if (onMediaChange) {
      onMediaChange(updatedMedia);
    }

    // Close preview if we're removing the current preview file
    if (previewFile && previewFile.id === id) {
      setPreviewFile(null);
    }

    toast({
      title: 'Media Removed',
      description: 'The media file has been removed.',
    });
  };

  const openImageUpload = () => {
    if (imageInputRef.current) {
      imageInputRef.current.click();
    }
  };

  const openCADUpload = () => {
    if (cadInputRef.current) {
      cadInputRef.current.click();
    }
  };

  const openPreview = (file: MediaFile) => {
    setPreviewFile(file);
  };

  const closePreview = () => {
    setPreviewFile(null);
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>Media Manager</CardTitle>
          <CardDescription>
            {canUpload 
              ? 'Upload and manage images and 3D CAD models'
              : 'View uploaded media files'
            }
          </CardDescription>
        </CardHeader>
        
        <CardContent>
          {canUpload && (
            <div className="flex flex-wrap gap-3 mb-4">
              <Button variant="outline" onClick={openImageUpload}>
                Upload Image
              </Button>
              <Button variant="outline" onClick={openCADUpload}>
                Upload 3D Model
              </Button>
              <Input
                ref={imageInputRef}
                type="file"
                accept="image/jpeg,image/png,image/gif"
                className="hidden"
                onChange={(e) => handleFileUpload(e, 'image')}
              />
              <Input
                ref={cadInputRef}
                type="file"
                accept=".glb,.gltf"
                className="hidden"
                onChange={(e) => handleFileUpload(e, 'cad')}
              />
            </div>
          )}
          
          {media.length === 0 ? (
            <div className="text-center py-12 border-2 border-dashed rounded-md text-gray-400">
              No media files uploaded yet.
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {media.map((file) => (
                <div
                  key={file.id}
                  className="relative group border rounded-md overflow-hidden"
                >
                  {file.type === 'image' ? (
                    <img
                      src={file.url}
                      alt={file.name}
                      className="w-full h-32 object-cover"
                    />
                  ) : (
                    <div className="w-full h-32 bg-gray-100 flex items-center justify-center">
                      <svg xmlns="http://www.w3.org/2000/svg" className="h-12 w-12 text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                      </svg>
                    </div>
                  )}
                  
                  <div className="text-xs truncate p-2 bg-white border-t">
                    {file.name}
                  </div>
                  
                  {/* Overlay with actions */}
                  <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                    <div className="flex space-x-2">
                      <Button size="sm" variant="default" onClick={() => openPreview(file)}>
                        Preview
                      </Button>
                      {canUpload && (
                        <Button size="sm" variant="destructive" onClick={() => handleRemoveMedia(file.id)}>
                          Remove
                        </Button>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
        
        <CardFooter className="text-sm text-gray-500">
          {media.length} media files in library
        </CardFooter>
      </Card>
      
      {/* Preview Modal */}
      {previewFile && (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50 p-4" onClick={closePreview}>
          <div className="bg-white rounded-lg max-w-3xl w-full max-h-[80vh] overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="flex justify-between items-center p-4 border-b">
              <h3 className="font-medium">{previewFile.name}</h3>
              <Button variant="ghost" size="sm" onClick={closePreview}>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clipRule="evenodd" />
                </svg>
              </Button>
            </div>
            
            <div className="p-4 flex items-center justify-center" style={{ height: '60vh' }}>
              {previewFile.type === 'image' ? (
                <img
                  src={previewFile.url}
                  alt={previewFile.name}
                  className="max-w-full max-h-full object-contain"
                />
              ) : (
                <div className="w-full h-full flex items-center justify-center bg-gray-100">
                  <div className="text-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-16 w-16 mx-auto text-gray-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
                    </svg>
                    <p className="mt-2">3D preview not available in this view</p>
                    <p className="text-sm text-gray-500">Download or use in the configurator to view in 3D</p>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
};

export default MediaManager;
