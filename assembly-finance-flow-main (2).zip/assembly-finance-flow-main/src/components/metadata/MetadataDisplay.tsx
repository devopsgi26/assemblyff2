
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { UserAction } from '@/types/module';

interface MetadataDisplayProps {
  moduleHistory: UserAction[];
  isVisible: boolean;
  isAdminOrManager: boolean;
}

const MetadataDisplay: React.FC<MetadataDisplayProps> = ({ 
  moduleHistory, 
  isVisible,
  isAdminOrManager 
}) => {
  if (!isVisible || !isAdminOrManager) return null;
  
  return (
    <Card className="bg-gray-50 border-gray-300">
      <CardHeader>
        <CardTitle>System Metadata & Audit Trail</CardTitle>
        <CardDescription>Track changes and modifications to the system</CardDescription>
      </CardHeader>
      <CardContent className="max-h-96 overflow-y-auto">
        {moduleHistory.length > 0 ? (
          <div className="space-y-2">
            {moduleHistory.map((action, index) => (
              <div key={index} className="bg-white p-3 rounded shadow-sm">
                <div className="flex justify-between">
                  <span className="font-medium">{action.actionType}</span>
                  <span className="text-sm text-gray-500">{new Date(action.timestamp).toLocaleString()}</span>
                </div>
                <div className="text-sm">User: {action.userName} (ID: {action.userId})</div>
                <div className="text-sm mt-1 text-gray-700">
                  {Object.entries(action.details).map(([key, value]) => (
                    <div key={key}>
                      {key}: {JSON.stringify(value)}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center py-6 text-gray-500">
            No activity recorded yet
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default MetadataDisplay;
