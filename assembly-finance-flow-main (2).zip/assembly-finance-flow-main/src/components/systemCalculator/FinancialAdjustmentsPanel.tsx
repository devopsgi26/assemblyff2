
import React, { useState, useEffect } from 'react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/context/AuthContext';
import { FinancialAdjustments } from '@/types/module';
import { formatPercent } from '@/utils/rounding';

interface FinancialAdjustmentsPanelProps {
  adjustments: FinancialAdjustments;
  onAdjustmentsChange: (adjustments: Partial<FinancialAdjustments>) => void;
}

const FinancialAdjustmentsPanel: React.FC<FinancialAdjustmentsPanelProps> = ({
  adjustments,
  onAdjustmentsChange,
}) => {
  const { hasPermission } = useAuth();
  const canEdit = hasPermission('editFinancials');
  
  // Local state to track inputs
  const [localAdjustments, setLocalAdjustments] = useState(adjustments);
  
  // Update local state when props change
  useEffect(() => {
    setLocalAdjustments(adjustments);
  }, [adjustments]);
  
  // Load saved adjustments from localStorage when component mounts
  useEffect(() => {
    const savedAdjustments = localStorage.getItem('financialAdjustments');
    if (savedAdjustments) {
      try {
        const parsedAdjustments = JSON.parse(savedAdjustments);
        onAdjustmentsChange(parsedAdjustments);
      } catch (e) {
        console.error('Failed to parse saved financial adjustments:', e);
      }
    }
  }, []);

  // Save adjustments to localStorage when they change
  useEffect(() => {
    localStorage.setItem('financialAdjustments', JSON.stringify(adjustments));
  }, [adjustments]);

  const handlePercentChange = (key: keyof FinancialAdjustments, value: string) => {
    if (canEdit) {
      const numValue = parseFloat(value) / 100;
      if (!isNaN(numValue) && numValue >= 0 && numValue <= 1) {
        const newAdjustments = { ...localAdjustments, [key]: numValue };
        setLocalAdjustments(newAdjustments);
        onAdjustmentsChange({ [key]: numValue });
      }
    }
  };

  const handleCurrencyRateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (canEdit) {
      const value = parseFloat(e.target.value);
      if (!isNaN(value) && value > 0) {
        const newAdjustments = { ...localAdjustments, currencyRate: value };
        setLocalAdjustments(newAdjustments);
        onAdjustmentsChange({ currencyRate: value });
      }
    }
  };
  
  const handleWarrantyPeriodChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (canEdit) {
      const value = parseInt(e.target.value);
      if (!isNaN(value) && value >= 0) {
        const newAdjustments = { ...localAdjustments, warrantyPeriod: value };
        setLocalAdjustments(newAdjustments);
        onAdjustmentsChange({ warrantyPeriod: value });
      }
    }
  };

  return (
    <Card className={canEdit ? '' : 'opacity-90'}>
      <CardHeader>
        <CardTitle>Financial Adjustments</CardTitle>
        <CardDescription>
          {canEdit
            ? 'Adjust financial parameters to calculate the final price'
            : 'View current financial parameters (requires higher permissions to edit)'}
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Margin */}
        <div className="space-y-2">
          <Label htmlFor="margin">Margin (%)</Label>
          <Input
            id="margin"
            type="number"
            min={0}
            max={100}
            step={0.1}
            disabled={!canEdit}
            value={(localAdjustments.margin * 100).toFixed(1)}
            onChange={(e) => handlePercentChange('margin', e.target.value)}
          />
        </div>

        {/* Bank Warranty */}
        <div className="space-y-2">
          <Label htmlFor="bankWarranty">Bank Warranty (%)</Label>
          <Input
            id="bankWarranty"
            type="number"
            min={0}
            max={100}
            step={0.5}
            disabled={!canEdit}
            value={(localAdjustments.bankWarranty * 100).toFixed(1)}
            onChange={(e) => handlePercentChange('bankWarranty', e.target.value)}
          />
        </div>

        {/* Risk Factor */}
        <div className="space-y-2">
          <Label htmlFor="riskFactor">Risk Factor (%)</Label>
          <Input
            id="riskFactor"
            type="number"
            min={0}
            max={100}
            step={0.5}
            disabled={!canEdit}
            value={(localAdjustments.riskFactor * 100).toFixed(1)}
            onChange={(e) => handlePercentChange('riskFactor', e.target.value)}
          />
        </div>

        {/* Admin Fees */}
        <div className="space-y-2">
          <Label htmlFor="adminFees">Admin Fees (%)</Label>
          <Input
            id="adminFees"
            type="number"
            min={0}
            max={100}
            step={0.5}
            disabled={!canEdit}
            value={(localAdjustments.adminFees * 100).toFixed(1)}
            onChange={(e) => handlePercentChange('adminFees', e.target.value)}
          />
        </div>

        {/* Ramp-Up */}
        <div className="space-y-2">
          <Label htmlFor="rampUp">Ramp-Up (%)</Label>
          <Input
            id="rampUp"
            type="number"
            min={0}
            max={100}
            step={0.5}
            disabled={!canEdit}
            value={(localAdjustments.rampUp * 100).toFixed(1)}
            onChange={(e) => handlePercentChange('rampUp', e.target.value)}
          />
        </div>

        {/* Currency Risk */}
        <div className="space-y-2">
          <Label htmlFor="currencyRisk">Currency Risk (%)</Label>
          <Input
            id="currencyRisk"
            type="number"
            min={0}
            max={100}
            step={0.5}
            disabled={!canEdit}
            value={(localAdjustments.currencyRisk * 100).toFixed(1)}
            onChange={(e) => handlePercentChange('currencyRisk', e.target.value)}
          />
        </div>

        {/* Currency Rate */}
        <div className="space-y-2">
          <Label htmlFor="currencyRate">Currency Rate (EUR × Rate)</Label>
          <div className="flex items-center space-x-2">
            <span className="text-sm font-medium">€ ×</span>
            <Input
              id="currencyRate"
              type="number"
              min={0.01}
              step={0.01}
              disabled={!canEdit}
              value={localAdjustments.currencyRate}
              onChange={handleCurrencyRateChange}
            />
          </div>
        </div>
        
        {/* Warranty Period (New) */}
        <div className="space-y-2">
          <Label htmlFor="warrantyPeriod">Warranty Period (months)</Label>
          <Input
            id="warrantyPeriod"
            type="number"
            min={0}
            step={1}
            disabled={!canEdit}
            value={localAdjustments.warrantyPeriod || 0}
            onChange={handleWarrantyPeriodChange}
          />
        </div>
      </CardContent>
    </Card>
  );
};

export default FinancialAdjustmentsPanel;
