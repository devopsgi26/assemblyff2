
import React, { useState } from 'react';
import { AssemblyModule } from '@/types/module';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { formatCurrency } from '@/utils/rounding';
import ModuleItem from './modules/ModuleItem';
import EditModuleForm from './modules/EditModuleForm';

interface ProcessCategoryModuleProps {
  title: string;
  modules: AssemblyModule[];
  onUpdateModule: (moduleId: string, updates: Partial<AssemblyModule>) => void;
  onRemoveModule: (moduleId: string) => void;
  categoryTotal: number;
  onReorderModules?: (sourceId: string, targetId: string) => void;
  isDraggable?: boolean;
}

const ProcessCategoryModule: React.FC<ProcessCategoryModuleProps> = ({
  title,
  modules,
  onUpdateModule,
  onRemoveModule,
  categoryTotal,
  onReorderModules,
  isDraggable = false,
}) => {
  const [expanded, setExpanded] = useState(true);
  const [editingModuleId, setEditingModuleId] = useState<string | null>(null);

  const toggleExpanded = () => {
    setExpanded(!expanded);
  };

  const handleStartEdit = (moduleId: string) => {
    setEditingModuleId(moduleId);
  };

  const handleSaveEdit = (module: AssemblyModule, updates: Partial<AssemblyModule>) => {
    onUpdateModule(module.id, updates);
    setEditingModuleId(null);
  };

  const handleCancelEdit = () => {
    setEditingModuleId(null);
  };

  return (
    <Card className="mb-4">
      <CardHeader className="py-3 flex flex-row items-center justify-between cursor-pointer" onClick={toggleExpanded}>
        <CardTitle className="text-md font-medium flex items-center">
          {expanded ? <ChevronDown className="mr-2 h-5 w-5" /> : <ChevronUp className="mr-2 h-5 w-5" />}
          {title}
        </CardTitle>
        <div className="font-bold text-lg">{formatCurrency(categoryTotal)}</div>
      </CardHeader>
      
      {expanded && (
        <CardContent className="py-2">
          <div className="space-y-3">
            {modules.length === 0 ? (
              <p className="text-gray-500 text-center py-2">No modules in this category</p>
            ) : (
              modules.map((module) => (
                editingModuleId === module.id ? (
                  <EditModuleForm 
                    key={module.id}
                    module={module} 
                    onSave={handleSaveEdit} 
                    onCancel={handleCancelEdit} 
                  />
                ) : (
                  <ModuleItem
                    key={module.id}
                    module={module}
                    onStartEdit={handleStartEdit}
                    onRemove={onRemoveModule}
                    isDraggable={!!isDraggable}
                    onReorder={onReorderModules}
                  />
                )
              ))
            )}
          </div>
        </CardContent>
      )}
    </Card>
  );
};

export default ProcessCategoryModule;
