
import React, { useState, useEffect } from 'react';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useAuth } from '@/context/AuthContext';

interface RatesPanelProps {
  rates: {
    engineeringRate: number;
    manufacturingRate: number;
    installationRate: number;
    logisticsRate: number;
  };
  onRatesChange: (rates: Partial<RatesPanelProps['rates']>) => void;
}

const RatesPanel: React.FC<RatesPanelProps> = ({
  rates,
  onRatesChange,
}) => {
  const { user, hasPermission } = useAuth();
  const canEdit = hasPermission('editDefaults');
  
  // Local state to track inputs
  const [localRates, setLocalRates] = useState(rates);
  
  // Update local state when props change
  useEffect(() => {
    setLocalRates(rates);
  }, [rates]);

  // Load saved rates from localStorage when component mounts
  useEffect(() => {
    const savedRates = localStorage.getItem('hourlyRates');
    if (savedRates) {
      try {
        const parsedRates = JSON.parse(savedRates);
        onRatesChange(parsedRates);
      } catch (e) {
        console.error('Failed to parse saved hourly rates:', e);
      }
    }
  }, []);

  // Save rates to localStorage when they change
  useEffect(() => {
    localStorage.setItem('hourlyRates', JSON.stringify(rates));
  }, [rates]);
  
  const handleRateChange = (key: keyof RatesPanelProps['rates'], value: string) => {
    if (canEdit) {
      const numValue = parseFloat(value);
      if (!isNaN(numValue) && numValue >= 0) {
        const newRates = { ...localRates, [key]: numValue };
        setLocalRates(newRates);
        onRatesChange({ [key]: numValue });
      }
    }
  };

  return (
    <Card className={canEdit ? '' : 'opacity-90'}>
      <CardHeader>
        <CardTitle>Hourly Rates</CardTitle>
        <CardDescription>
          {canEdit
            ? 'Edit hourly rates for different categories'
            : 'View current hourly rates (requires admin permissions to edit)'}
        </CardDescription>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="space-y-2">
          <Label htmlFor="engineeringRate">Engineering Rate (€/hour)</Label>
          <Input
            id="engineeringRate"
            type="number"
            min={0}
            disabled={!canEdit}
            value={localRates.engineeringRate}
            onChange={(e) => handleRateChange('engineeringRate', e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="manufacturingRate">Manufacturing Rate (€/hour)</Label>
          <Input
            id="manufacturingRate"
            type="number"
            min={0}
            disabled={!canEdit}
            value={localRates.manufacturingRate}
            onChange={(e) => handleRateChange('manufacturingRate', e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="installationRate">Installation Rate (€/hour)</Label>
          <Input
            id="installationRate"
            type="number"
            min={0}
            disabled={!canEdit}
            value={localRates.installationRate}
            onChange={(e) => handleRateChange('installationRate', e.target.value)}
          />
        </div>

        <div className="space-y-2">
          <Label htmlFor="logisticsRate">Logistics Rate (% of BOM)</Label>
          <Input
            id="logisticsRate"
            type="number"
            min={0}
            max={100}
            disabled={!canEdit}
            value={localRates.logisticsRate}
            onChange={(e) => handleRateChange('logisticsRate', e.target.value)}
          />
        </div>
        
        {!canEdit && (
          <p className="text-sm text-amber-600 mt-2">
            Note: Only administrators can modify hourly rates
          </p>
        )}
        {canEdit && (
          <p className="text-sm text-gray-500 mt-2">
            Last edited by: {user?.name || 'System'} at {new Date().toLocaleString()}
          </p>
        )}
      </CardContent>
    </Card>
  );
};

export default RatesPanel;
