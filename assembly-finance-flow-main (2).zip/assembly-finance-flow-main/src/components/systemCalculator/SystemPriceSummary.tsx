
import React from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { AssemblyModule, FinancialAdjustments, TravelCost } from '@/types/module';
import { formatCurrency } from '@/utils/rounding';
import { getDetailedCostBreakdown } from '@/lib/calculations/financialCalculations';
import { FileText, FileDown } from 'lucide-react';
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';

interface SystemPriceSummaryProps {
  modules: AssemblyModule[];
  travelCosts: TravelCost[];
  financialAdjustments: FinancialAdjustments;
  hourlyRates?: {
    engineeringRate: number;
    manufacturingRate: number;
    installationRate: number;
    logisticsRate: number;
  };
  onExport?: () => void;
  onExportPdf?: () => void;
  onExportWord?: () => void;
}

const SystemPriceSummary: React.FC<SystemPriceSummaryProps> = ({
  modules,
  travelCosts,
  financialAdjustments,
  hourlyRates = {
    engineeringRate: 85,
    manufacturingRate: 65,
    installationRate: 95,
    logisticsRate: 8
  },
  onExport,
  onExportPdf,
  onExportWord,
}) => {
  const breakdown = getDetailedCostBreakdown(modules, travelCosts, financialAdjustments);

  // Calculate the currency symbol based on the rate
  const currencySymbol = financialAdjustments.currencyRate === 1 ? '€' : '$';

  // Calculate labor hours
  const engineeringHours = modules.reduce((total, module) => {
    return total + (module.costs.engineering / hourlyRates.engineeringRate) * module.quantity;
  }, 0);

  const manufacturingHours = modules.reduce((total, module) => {
    return total + (module.costs.manufacturing / hourlyRates.manufacturingRate) * module.quantity;
  }, 0);

  const installationHours = travelCosts.reduce((total, cost) => {
    return total + cost.standardTime + cost.overtimeHours + cost.premiumTimeHours;
  }, 0);

  const totalLaborHours = engineeringHours + manufacturingHours + installationHours;

  const handleExportToPdf = () => {
    if (onExportPdf) {
      onExportPdf();
      return;
    }

    const element = document.getElementById('system-price-summary');
    if (!element) return;

    // Add a unique class to preserve styling during export
    element.classList.add('pdf-export');

    html2canvas(element, {
      scale: 2,
      useCORS: true,
      allowTaint: true,
      logging: true,
      backgroundColor: '#ffffff'
    }).then(canvas => {
      const imgData = canvas.toDataURL('image/png');
      const pdf = new jsPDF({
        orientation: 'portrait',
        unit: 'mm',
        format: 'a4'
      });

      const imgWidth = 210; // A4 width in mm
      const pageHeight = 297; // A4 height in mm
      const imgHeight = canvas.height * imgWidth / canvas.width;

      let heightLeft = imgHeight;
      let position = 0;
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;

      while (heightLeft >= 0) {
        position = heightLeft - imgHeight;
        pdf.addPage();
        pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
        heightLeft -= pageHeight;
      }
      
      pdf.save(`System_Price_Summary_${new Date().toISOString().slice(0, 10)}.pdf`);
      
      // Remove the export class
      element.classList.remove('pdf-export');
    });
  };

  const handleExportToWord = () => {
    if (onExportWord) {
      onExportWord();
      return;
    }

    const element = document.getElementById('system-price-summary');
    if (!element) return;

    // Get the HTML content
    const htmlContent = `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <title>System Price Summary</title>
        <style>
          body { font-family: Arial, sans-serif; color: #333; }
          .container { max-width: 800px; margin: 0 auto; padding: 20px; }
          h1 { color: #2563eb; }
          .section { margin-bottom: 20px; }
          .section-title { font-weight: bold; margin-bottom: 10px; }
          .row { display: flex; justify-content: space-between; margin-bottom: 5px; }
          .total { font-weight: bold; border-top: 1px solid #ddd; padding-top: 5px; }
        </style>
      </head>
      <body>
        <div class="container">
          <h1>System Price Summary</h1>
          
          <div class="section">
            <div class="section-title">Labor Hours</div>
            <div class="row">
              <span>Engineering Hours</span>
              <span>${engineeringHours.toFixed(1)} hrs</span>
            </div>
            <div class="row">
              <span>Manufacturing Hours</span>
              <span>${manufacturingHours.toFixed(1)} hrs</span>
            </div>
            <div class="row">
              <span>Installation Hours</span>
              <span>${installationHours.toFixed(1)} hrs</span>
            </div>
            <div class="row total">
              <span>Total Labor Hours</span>
              <span>${totalLaborHours.toFixed(1)} hrs</span>
            </div>
          </div>
          
          <div class="section">
            <div class="section-title">Base Costs</div>
            <div class="row">
              <span>Engineering</span>
              <span>${formatCurrency(breakdown.baseCosts.engineering)}</span>
            </div>
            <div class="row">
              <span>Manufacturing</span>
              <span>${formatCurrency(breakdown.baseCosts.manufacturing)}</span>
            </div>
            <div class="row">
              <span>Bill of Materials</span>
              <span>${formatCurrency(breakdown.baseCosts.bom)}</span>
            </div>
            <div class="row">
              <span>Travel & Installation</span>
              <span>${formatCurrency(breakdown.baseCosts.travel)}</span>
            </div>
            <div class="row">
              <span>Logistics</span>
              <span>${formatCurrency(breakdown.baseCosts.logistics)}</span>
            </div>
            <div class="row total">
              <span>Base Cost Total</span>
              <span>${formatCurrency(breakdown.baseCosts.total)}</span>
            </div>
          </div>
          
          <div class="section">
            <div class="section-title">Adjustments</div>
            <div class="row">
              <span>Risk Factor</span>
              <span>${formatCurrency(breakdown.adjustments.riskFactor)}</span>
            </div>
            <div class="row">
              <span>Admin Fees</span>
              <span>${formatCurrency(breakdown.adjustments.adminFees)}</span>
            </div>
            <div class="row">
              <span>Ramp-Up</span>
              <span>${formatCurrency(breakdown.adjustments.rampUp)}</span>
            </div>
            <div class="row">
              <span>Bank Warranty</span>
              <span>${formatCurrency(breakdown.adjustments.bankWarranty)}</span>
            </div>
            <div class="row">
              <span>Currency Risk</span>
              <span>${formatCurrency(breakdown.adjustments.currencyRisk)}</span>
            </div>
            <div class="row">
              <span>Subtotal Before Margin</span>
              <span>${formatCurrency(breakdown.totals.subtotalBeforeMargin)}</span>
            </div>
            <div class="row" style="color: #2563eb;">
              <span>Margin</span>
              <span>${formatCurrency(breakdown.adjustments.margin)}</span>
            </div>
          </div>
          
          <div class="section">
            <div class="row total" style="font-size: 1.2em;">
              <span>Total Price (EUR)</span>
              <span>${formatCurrency(breakdown.totals.totalPrice)}</span>
            </div>
            ${financialAdjustments.currencyRate !== 1 ? `
            <div class="row total" style="font-size: 1.2em; background-color: #f9fafb; padding: 10px;">
              <span>Converted Price</span>
              <span>${formatCurrency(breakdown.totals.convertedPrice, currencySymbol)}</span>
            </div>
            ` : ''}
          </div>
          
          <div style="margin-top: 30px; font-size: 0.8em; color: #666;">
            Generated on ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}
          </div>
        </div>
      </body>
      </html>
    `;

    // Create a Blob with the HTML content
    const blob = new Blob([htmlContent], { type: 'application/msword' });
    const url = URL.createObjectURL(blob);
    
    // Create a link and trigger download
    const link = document.createElement('a');
    link.href = url;
    link.download = `System_Price_Summary_${new Date().toISOString().slice(0, 10)}.doc`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  return (
    <Card className="bg-white" id="system-price-summary">
      <CardHeader className="pb-2">
        <CardTitle>System Price Summary</CardTitle>
        <CardDescription>Complete breakdown of all costs and adjustments</CardDescription>
      </CardHeader>

      <CardContent className="space-y-6">
        {/* Labor Hours Section */}
        <div>
          <h3 className="font-medium text-gray-800 mb-2">Labor Hours</h3>
          <div className="space-y-1 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600">Engineering Hours</span>
              <span>{engineeringHours.toFixed(1)} hrs</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Manufacturing Hours</span>
              <span>{manufacturingHours.toFixed(1)} hrs</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Installation Hours</span>
              <span>{installationHours.toFixed(1)} hrs</span>
            </div>
            <div className="flex justify-between pt-1 border-t border-gray-200 font-medium">
              <span>Total Labor Hours</span>
              <span>{totalLaborHours.toFixed(1)} hrs</span>
            </div>
          </div>
        </div>

        {/* Base Costs Section */}
        <div>
          <h3 className="font-medium text-gray-800 mb-2">Base Costs</h3>
          <div className="space-y-1 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600">Engineering</span>
              <span>{formatCurrency(breakdown.baseCosts.engineering)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Manufacturing</span>
              <span>{formatCurrency(breakdown.baseCosts.manufacturing)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Bill of Materials</span>
              <span>{formatCurrency(breakdown.baseCosts.bom)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Travel & Installation</span>
              <span>{formatCurrency(breakdown.baseCosts.travel)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Logistics</span>
              <span>{formatCurrency(breakdown.baseCosts.logistics)}</span>
            </div>
            <div className="flex justify-between pt-1 border-t border-gray-200 font-medium">
              <span>Base Cost Total</span>
              <span>{formatCurrency(breakdown.baseCosts.total)}</span>
            </div>
          </div>
        </div>

        {/* Adjustments Section */}
        <div>
          <h3 className="font-medium text-gray-800 mb-2">Adjustments</h3>
          <div className="space-y-1 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600">Risk Factor</span>
              <span>{formatCurrency(breakdown.adjustments.riskFactor)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Admin Fees</span>
              <span>{formatCurrency(breakdown.adjustments.adminFees)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Ramp-Up</span>
              <span>{formatCurrency(breakdown.adjustments.rampUp)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Bank Warranty</span>
              <span>{formatCurrency(breakdown.adjustments.bankWarranty)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Currency Risk</span>
              <span>{formatCurrency(breakdown.adjustments.currencyRisk)}</span>
            </div>
            <div className="flex justify-between pt-1 border-t border-gray-200">
              <span className="font-medium">Subtotal Before Margin</span>
              <span className="font-medium">{formatCurrency(breakdown.totals.subtotalBeforeMargin)}</span>
            </div>
            <div className="flex justify-between text-engineering-primary">
              <span className="font-medium">Margin</span>
              <span className="font-medium">{formatCurrency(breakdown.adjustments.margin)}</span>
            </div>
          </div>
        </div>

        {/* Final Totals Section */}
        <div className="pt-2 border-t-2 border-gray-200">
          <div className="flex justify-between items-center">
            <span className="font-bold text-lg">Total Price (EUR)</span>
            <span className="font-bold text-xl text-engineering-primary">{formatCurrency(breakdown.totals.totalPrice)}</span>
          </div>
          
          {financialAdjustments.currencyRate !== 1 && (
            <div className="flex justify-between items-center mt-2 bg-gray-50 p-2 rounded">
              <span className="font-bold text-lg">Converted Price</span>
              <span className="font-bold text-xl text-engineering-primary">
                {formatCurrency(breakdown.totals.convertedPrice, currencySymbol)}
              </span>
            </div>
          )}
        </div>
      </CardContent>

      <CardFooter className="pt-0 flex flex-col gap-2">
        <div className="flex w-full gap-2">
          <Button 
            className="flex-1" 
            variant="outline" 
            onClick={onExport || (() => {})}
          >
            Export Price Summary
          </Button>
        </div>
        <div className="flex w-full gap-2">
          <Button 
            className="flex-1" 
            variant="outline" 
            onClick={handleExportToPdf}
          >
            <FileText className="mr-2 h-4 w-4" />
            Export to PDF
          </Button>
          <Button 
            className="flex-1" 
            variant="outline" 
            onClick={handleExportToWord}
          >
            <FileDown className="mr-2 h-4 w-4" />
            Export to Word
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
};

export default SystemPriceSummary;
