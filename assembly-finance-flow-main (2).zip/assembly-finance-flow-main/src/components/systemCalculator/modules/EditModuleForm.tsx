
import React, { useState } from 'react';
import { AssemblyModule } from '@/types/module';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';

interface EditModuleFormProps {
  module: AssemblyModule;
  onSave: (module: AssemblyModule, updates: Partial<AssemblyModule>) => void;
  onCancel: () => void;
}

const EditModuleForm: React.FC<EditModuleFormProps> = ({ module, onSave, onCancel }) => {
  const [quantity, setQuantity] = useState(module.quantity);
  const [engineering, setEngineering] = useState(module.costs.engineering);
  const [manufacturing, setManufacturing] = useState(module.costs.manufacturing);
  const [bom, setBom] = useState(module.costs.bom);

  const handleSave = () => {
    onSave(module, {
      quantity,
      costs: {
        engineering,
        manufacturing,
        bom
      }
    });
  };

  return (
    <div className="space-y-3 border rounded-md p-3 bg-gray-50">
      <h4 className="font-medium">Edit {module.name}</h4>
      
      <div className="grid grid-cols-2 gap-2">
        <div>
          <label className="text-xs text-gray-500 mb-1 block">Quantity</label>
          <Input
            type="number"
            min={1}
            value={quantity}
            onChange={(e) => setQuantity(parseInt(e.target.value) || 1)}
            className="h-8"
          />
        </div>
        <div>
          <label className="text-xs text-gray-500 mb-1 block">Engineering Cost</label>
          <Input
            type="number"
            min={0}
            step={100}
            value={engineering}
            onChange={(e) => setEngineering(parseFloat(e.target.value) || 0)}
            className="h-8"
          />
        </div>
        <div>
          <label className="text-xs text-gray-500 mb-1 block">Manufacturing Cost</label>
          <Input
            type="number"
            min={0}
            step={100}
            value={manufacturing}
            onChange={(e) => setManufacturing(parseFloat(e.target.value) || 0)}
            className="h-8"
          />
        </div>
        <div>
          <label className="text-xs text-gray-500 mb-1 block">BOM Cost</label>
          <Input
            type="number"
            min={0}
            step={100}
            value={bom}
            onChange={(e) => setBom(parseFloat(e.target.value) || 0)}
            className="h-8"
          />
        </div>
      </div>
      
      <div className="flex justify-end space-x-2 pt-2">
        <Button variant="outline" size="sm" onClick={onCancel}>Cancel</Button>
        <Button size="sm" onClick={handleSave}>Save</Button>
      </div>
    </div>
  );
};

export default EditModuleForm;
