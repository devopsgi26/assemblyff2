
import React, { useRef, useState } from 'react';
import { AssemblyModule } from '@/types/module';
import { Button } from '@/components/ui/button';
import { 
  Edit, 
  Trash2, 
  MoveVertical,
  AlertCircle
} from 'lucide-react';
import { formatCurrency } from '@/utils/rounding';
import { useAuth } from '@/context/AuthContext';
import { useDrag, useDrop } from 'react-dnd';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";

interface ModuleItemProps {
  module: AssemblyModule;
  onStartEdit: (moduleId: string) => void;
  onRemove: (moduleId: string) => void;
  isDraggable: boolean;
  onReorder?: (sourceId: string, targetId: string) => void;
}

const ModuleItem: React.FC<ModuleItemProps> = ({
  module,
  onStartEdit,
  onRemove,
  isDraggable,
  onReorder,
}) => {
  const { hasPermission } = useAuth();
  const canEdit = hasPermission('editFinancials');
  const ref = useRef<HTMLDivElement>(null);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);

  const [{ isDragging }, drag] = useDrag({
    type: 'MODULE',
    item: { id: module.id, type: 'MODULE' },
    collect: (monitor) => ({
      isDragging: monitor.isDragging(),
    }),
    canDrag: isDraggable && canEdit,
  });

  const [{ isOver }, drop] = useDrop({
    accept: 'MODULE',
    hover(item: { id: string; type: string }, monitor) {
      if (!ref.current) {
        return;
      }
      
      const dragId = item.id;
      const hoverId = module.id;
      
      // Don't replace items with themselves
      if (dragId === hoverId) {
        return;
      }
      
      // If we can reorder, call the handler
      if (onReorder) {
        onReorder(dragId, hoverId);
      }
    },
    collect: (monitor) => ({
      isOver: !!monitor.isOver(),
    }),
  });
  
  // Initialize the drag and drop refs
  drag(drop(ref));

  const handleDelete = () => {
    setIsDeleteDialogOpen(true);
  };

  const confirmDelete = () => {
    onRemove(module.id);
    setIsDeleteDialogOpen(false);
  };

  return (
    <>
      <div 
        ref={ref}
        className={`border rounded-md p-3 hover:bg-gray-50 transition-colors ${
          isDragging ? 'opacity-50' : ''
        } ${
          isOver ? 'border-blue-500' : ''
        }`}
      >
        <div className="flex items-center justify-between">
          <div className="flex flex-col">
            <div className="flex items-center">
              {isDraggable && canEdit && (
                <MoveVertical className="h-4 w-4 text-gray-400 mr-2 cursor-move" />
              )}
              <span className="font-medium">{module.name}</span>
            </div>
            <span className="text-sm text-gray-500">Quantity: {module.quantity}</span>
          </div>
          <div className="flex items-center space-x-2">
            <span className="font-medium">{formatCurrency(
              module.costs.engineering + module.costs.manufacturing + module.costs.bom
            )}</span>
            {canEdit && (
              <>
                <Button 
                  variant="ghost" 
                  size="sm"
                  onClick={(e) => {
                    e.stopPropagation();
                    onStartEdit(module.id);
                  }}
                >
                  <Edit className="h-4 w-4" />
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  onClick={(e) => {
                    e.stopPropagation();
                    handleDelete();
                  }}
                >
                  <Trash2 className="h-4 w-4 text-red-500" />
                </Button>
              </>
            )}
          </div>
        </div>
      </div>

      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <AlertCircle className="h-5 w-5 text-red-500" />
              Delete Module
            </AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to remove "{module.name}" from this category?
              This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmDelete} className="bg-red-600 hover:bg-red-700">
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </>
  );
};

export default ModuleItem;
