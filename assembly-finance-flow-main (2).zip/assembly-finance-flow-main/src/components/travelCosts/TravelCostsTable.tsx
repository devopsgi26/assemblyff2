import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { TravelCost } from '@/types/module';
import { formatCurrency } from '@/utils/rounding';
import { Trash2, Plus } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';

interface TravelCostsTableProps {
  travelCosts: TravelCost[];
  onAddCost: (cost: TravelCost) => void;
  onUpdateCost: (index: number, cost: Partial<TravelCost>) => void;
  onRemoveCost: (index: number) => void;
}

const TravelCostsTable: React.FC<TravelCostsTableProps> = ({
  travelCosts,
  onAddCost,
  onUpdateCost,
  onRemoveCost,
}) => {
  const { hasPermission } = useAuth();
  const canEdit = hasPermission('editTravelCosts');
  
  const [newCost, setNewCost] = useState<TravelCost>({
    personnelType: 'Engineer',
    standardTime: 8,
    overtimeHours: 0,
    premiumTimeHours: 0,
    travelTime: 2,
    carExpenses: 0,
    hotel: 0,
    allowance: 0,
  });
  
  // Local state to track inputs
  const [localTravelCosts, setLocalTravelCosts] = useState<TravelCost[]>(travelCosts);
  
  // Update local state when props change
  useEffect(() => {
    setLocalTravelCosts(travelCosts);
  }, [travelCosts]);
  
  // Load saved travel costs from localStorage when component mounts
  useEffect(() => {
    const savedTravelCosts = localStorage.getItem('travelCosts');
    if (savedTravelCosts) {
      try {
        const parsedTravelCosts = JSON.parse(savedTravelCosts);
        // Don't update if we already have travel costs
        if (travelCosts.length === 0 && parsedTravelCosts.length > 0) {
          parsedTravelCosts.forEach((cost: TravelCost) => {
            onAddCost(cost);
          });
        }
      } catch (e) {
        console.error('Failed to parse saved travel costs:', e);
      }
    }
  }, []);

  // Save travel costs to localStorage when they change
  useEffect(() => {
    localStorage.setItem('travelCosts', JSON.stringify(travelCosts));
  }, [travelCosts]);

  const handleInputChange = (field: keyof TravelCost, value: string | number) => {
    setNewCost((prev) => ({
      ...prev,
      [field]: typeof value === 'string' && field !== 'personnelType' 
        ? parseFloat(value) || 0
        : value,
    }));
  };

  const handleAddCost = () => {
    onAddCost(newCost);
    // Reset form after adding
    setNewCost({
      personnelType: 'Engineer',
      standardTime: 8,
      overtimeHours: 0,
      premiumTimeHours: 0,
      travelTime: 2,
      carExpenses: 0,
      hotel: 0,
      allowance: 0,
    });
  };

  const handleUpdateCost = (index: number, field: keyof TravelCost, value: string | number) => {
    const updatedValue = typeof value === 'string' && field !== 'personnelType' 
      ? parseFloat(value) || 0
      : value;
      
    onUpdateCost(index, { [field]: updatedValue });
  };
  
  // Calculate total cost for one travel cost entry
  const calculateTotalCost = (cost: TravelCost): number => {
    // This would ideally use the hourly rates from the context
    const hourlyRate = cost.personnelType === 'Engineer' ? 85 : 
                       cost.personnelType === 'Technician' ? 65 : 95;
                       
    const standardTimeCost = cost.standardTime * hourlyRate;
    const overtimeCost = cost.overtimeHours * hourlyRate * 1.25;  // 25% overtime premium
    const premiumTimeCost = cost.premiumTimeHours * hourlyRate * 1.6;  // 60% premium time
    const travelTimeCost = cost.travelTime * hourlyRate;
    
    const expenses = cost.carExpenses + cost.hotel + cost.allowance;
    
    return standardTimeCost + overtimeCost + premiumTimeCost + travelTimeCost + expenses;
  };

  return (
    <div className="space-y-4">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Personnel Type</TableHead>
            <TableHead>Standard Time (hrs)</TableHead>
            <TableHead>Overtime (hrs)</TableHead>
            <TableHead>Premium Time (hrs)</TableHead>
            <TableHead>Travel Time (hrs)</TableHead>
            <TableHead>Car Expenses (€)</TableHead>
            <TableHead>Hotel (€)</TableHead>
            <TableHead>Allowance (€)</TableHead>
            <TableHead>Total</TableHead>
            {canEdit && <TableHead className="w-[80px]">Actions</TableHead>}
          </TableRow>
        </TableHeader>
        <TableBody>
          {travelCosts.length === 0 ? (
            <TableRow>
              <TableCell colSpan={canEdit ? 10 : 9} className="text-center text-muted-foreground">
                No travel costs added yet
              </TableCell>
            </TableRow>
          ) : (
            travelCosts.map((cost, index) => (
              <TableRow key={index}>
                <TableCell>
                  <Select
                    disabled={!canEdit}
                    value={cost.personnelType}
                    onValueChange={(value) => handleUpdateCost(index, 'personnelType', value)}
                  >
                    <SelectTrigger className="w-[120px]">
                      <SelectValue placeholder="Select type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Engineer">Engineer</SelectItem>
                      <SelectItem value="Technician">Technician</SelectItem>
                      <SelectItem value="Manager">Manager</SelectItem>
                    </SelectContent>
                  </Select>
                </TableCell>
                <TableCell>
                  <Input
                    type="number"
                    min="0"
                    step="0.5"
                    disabled={!canEdit}
                    value={cost.standardTime}
                    onChange={(e) => handleUpdateCost(index, 'standardTime', e.target.value)}
                    className="w-[80px]"
                  />
                </TableCell>
                <TableCell>
                  <Input
                    type="number"
                    min="0"
                    step="0.5"
                    disabled={!canEdit}
                    value={cost.overtimeHours}
                    onChange={(e) => handleUpdateCost(index, 'overtimeHours', e.target.value)}
                    className="w-[80px]"
                  />
                </TableCell>
                <TableCell>
                  <Input
                    type="number"
                    min="0"
                    step="0.5"
                    disabled={!canEdit}
                    value={cost.premiumTimeHours}
                    onChange={(e) => handleUpdateCost(index, 'premiumTimeHours', e.target.value)}
                    className="w-[80px]"
                  />
                </TableCell>
                <TableCell>
                  <Input
                    type="number"
                    min="0"
                    step="0.5"
                    disabled={!canEdit}
                    value={cost.travelTime}
                    onChange={(e) => handleUpdateCost(index, 'travelTime', e.target.value)}
                    className="w-[80px]"
                  />
                </TableCell>
                <TableCell>
                  <Input
                    type="number"
                    min="0"
                    step="10"
                    disabled={!canEdit}
                    value={cost.carExpenses}
                    onChange={(e) => handleUpdateCost(index, 'carExpenses', e.target.value)}
                    className="w-[80px]"
                  />
                </TableCell>
                <TableCell>
                  <Input
                    type="number"
                    min="0"
                    step="10"
                    disabled={!canEdit}
                    value={cost.hotel}
                    onChange={(e) => handleUpdateCost(index, 'hotel', e.target.value)}
                    className="w-[80px]"
                  />
                </TableCell>
                <TableCell>
                  <Input
                    type="number"
                    min="0"
                    step="10"
                    disabled={!canEdit}
                    value={cost.allowance}
                    onChange={(e) => handleUpdateCost(index, 'allowance', e.target.value)}
                    className="w-[80px]"
                  />
                </TableCell>
                <TableCell className="font-medium">
                  {formatCurrency(calculateTotalCost(cost))}
                </TableCell>
                {canEdit && (
                  <TableCell>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => onRemoveCost(index)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </TableCell>
                )}
              </TableRow>
            ))
          )}
        </TableBody>
      </Table>

      {canEdit && (
        <div className="border p-4 rounded-md bg-gray-50">
          <h3 className="text-sm font-medium mb-3">Add New Travel Cost</h3>
          <div className="grid grid-cols-4 gap-4 mb-4">
            <div>
              <label className="text-xs text-gray-500 mb-1 block">Personnel Type</label>
              <Select
                value={newCost.personnelType}
                onValueChange={(value) => handleInputChange('personnelType', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Engineer">Engineer</SelectItem>
                  <SelectItem value="Technician">Technician</SelectItem>
                  <SelectItem value="Manager">Manager</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-xs text-gray-500 mb-1 block">Standard Time (hrs)</label>
              <Input
                type="number"
                min="0"
                step="0.5"
                value={newCost.standardTime}
                onChange={(e) => handleInputChange('standardTime', e.target.value)}
              />
            </div>

            <div>
              <label className="text-xs text-gray-500 mb-1 block">Overtime (hrs)</label>
              <Input
                type="number"
                min="0"
                step="0.5"
                value={newCost.overtimeHours}
                onChange={(e) => handleInputChange('overtimeHours', e.target.value)}
              />
            </div>

            <div>
              <label className="text-xs text-gray-500 mb-1 block">Premium Time (hrs)</label>
              <Input
                type="number"
                min="0"
                step="0.5"
                value={newCost.premiumTimeHours}
                onChange={(e) => handleInputChange('premiumTimeHours', e.target.value)}
              />
            </div>

            <div>
              <label className="text-xs text-gray-500 mb-1 block">Travel Time (hrs)</label>
              <Input
                type="number"
                min="0"
                step="0.5"
                value={newCost.travelTime}
                onChange={(e) => handleInputChange('travelTime', e.target.value)}
              />
            </div>

            <div>
              <label className="text-xs text-gray-500 mb-1 block">Car Expenses (€)</label>
              <Input
                type="number"
                min="0"
                step="10"
                value={newCost.carExpenses}
                onChange={(e) => handleInputChange('carExpenses', e.target.value)}
              />
            </div>

            <div>
              <label className="text-xs text-gray-500 mb-1 block">Hotel (€)</label>
              <Input
                type="number"
                min="0"
                step="10"
                value={newCost.hotel}
                onChange={(e) => handleInputChange('hotel', e.target.value)}
              />
            </div>

            <div>
              <label className="text-xs text-gray-500 mb-1 block">Allowance (€)</label>
              <Input
                type="number"
                min="0"
                step="10"
                value={newCost.allowance}
                onChange={(e) => handleInputChange('allowance', e.target.value)}
              />
            </div>
          </div>

          <div className="flex justify-end">
            <Button onClick={handleAddCost}>
              <Plus className="h-4 w-4 mr-1" /> Add Travel Cost
            </Button>
          </div>
        </div>
      )}
    </div>
  );
};

export default TravelCostsTable;
