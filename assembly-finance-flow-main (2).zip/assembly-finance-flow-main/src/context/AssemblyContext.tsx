
import React, { createContext, useContext, useState, ReactNode } from 'react';
import { AssemblyModule, MachineSpecs, FinancialAdjustments, SavedAssembly, TravelCost } from '@/types/module';
import { useToast } from '@/hooks/use-toast';
import { useModules } from '@/hooks/useModules';
import { useMachineSpecs } from '@/hooks/useMachineSpecs';
import { useFinancialAdjustments } from '@/hooks/useFinancialAdjustments';
import { useTravelCosts } from '@/hooks/useTravelCosts';
import { useSavedAssemblies } from '@/hooks/useSavedAssemblies';
import { usePersistence } from '@/hooks/usePersistence';

interface AssemblyContextType {
  modules: AssemblyModule[];
  availableModules: AssemblyModule[]; 
  machineSpecs: MachineSpecs;
  financialAdjustments: FinancialAdjustments;
  travelCosts: TravelCost[];
  savedAssemblies: SavedAssembly[];
  
  // Module functions
  addModule: (module: AssemblyModule) => void;
  removeModule: (moduleId: string) => void;
  updateModuleQuantity: (moduleId: string, quantity: number) => void;
  updateModule: (moduleId: string, updates: Partial<AssemblyModule>) => void;
  reorderModules: (sourceId: string, targetId: string) => void;
  deleteAvailableModule: (moduleId: string) => void;
  reorderAvailableModules: (sourceId: string, targetId: string) => void;
  createModule: (module: Omit<AssemblyModule, 'id'>) => AssemblyModule | null; // Updated return type
  
  // Machine specs functions
  updateMachineSpecs: (specs: Partial<MachineSpecs>) => void;
  
  // Financial adjustment functions
  updateFinancialAdjustments: (adjustments: Partial<FinancialAdjustments>) => void;
  
  // Travel costs functions
  addTravelCost: (cost: TravelCost) => void;
  updateTravelCost: (index: number, cost: Partial<TravelCost>) => void;
  removeTravelCost: (index: number) => void;
  
  // Assembly saving functions
  saveAssembly: (name: string) => void;
  loadAssembly: (assemblyId: string) => void;
  deleteAssembly: (assemblyId: string) => void;
  
  // Reset function
  resetAssembly: () => void;

  // Category functions
  getModulesByCategory: () => {
    engineering: AssemblyModule[];
    manufacturing: AssemblyModule[];
    bom: AssemblyModule[];
  };
  getCategoryCosts: () => {
    engineering: number;
    manufacturing: number;
    bom: number;
  };
}

const AssemblyContext = createContext<AssemblyContextType | undefined>(undefined);

export const AssemblyProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const {
    modules, 
    setModules,
    availableModules,
    setAvailableModules,
    addModule,
    removeModule,
    updateModuleQuantity,
    updateModule,
    deleteAvailableModule,
    reorderModules,
    reorderAvailableModules,
    createModule,
    getModulesByCategory,
    getCategoryCosts
  } = useModules();
  
  const {
    machineSpecs,
    setMachineSpecs,
    updateMachineSpecs,
    resetMachineSpecs
  } = useMachineSpecs();
  
  const {
    financialAdjustments,
    setFinancialAdjustments,
    updateFinancialAdjustments,
    resetFinancialAdjustments
  } = useFinancialAdjustments();
  
  const {
    travelCosts,
    setTravelCosts,
    addTravelCost,
    updateTravelCost,
    removeTravelCost,
    resetTravelCosts
  } = useTravelCosts();
  
  const {
    savedAssemblies,
    setSavedAssemblies,
    saveAssembly,
    loadAssembly,
    deleteAssembly
  } = useSavedAssemblies(
    modules,
    machineSpecs,
    financialAdjustments,
    travelCosts,
    setModules,
    setMachineSpecs,
    setFinancialAdjustments,
    setTravelCosts
  );
  
  // Handle persistence
  const {
    forceSave,
    clearPersistedData
  } = usePersistence({
    modules,
    machineSpecs,
    financialAdjustments,
    travelCosts,
    savedAssemblies,
    setModules,
    setMachineSpecs,
    setFinancialAdjustments,
    setTravelCosts,
    setSavedAssemblies
  });

  const { toast } = useToast();

  const resetAssembly = () => {
    try {
      setModules([]);
      resetMachineSpecs();
      resetFinancialAdjustments();
      resetTravelCosts();
      
      toast({
        title: 'Assembly Reset',
        description: 'All configuration data has been reset.',
      });
    } catch (error) {
      console.error('Failed to reset assembly:', error);
      toast({
        title: 'Reset Failed',
        description: 'Failed to reset assembly. Please try again.',
        variant: 'destructive',
      });
    }
  };

  return (
    <AssemblyContext.Provider
      value={{
        modules,
        availableModules,
        machineSpecs,
        financialAdjustments,
        travelCosts,
        savedAssemblies,
        addModule,
        removeModule,
        updateModuleQuantity,
        updateModule,
        deleteAvailableModule,
        reorderModules,
        reorderAvailableModules,
        createModule,
        updateMachineSpecs,
        updateFinancialAdjustments,
        addTravelCost,
        updateTravelCost,
        removeTravelCost,
        saveAssembly,
        loadAssembly,
        deleteAssembly,
        resetAssembly,
        getModulesByCategory,
        getCategoryCosts,
      }}
    >
      {children}
    </AssemblyContext.Provider>
  );
};

export const useAssembly = () => {
  const context = useContext(AssemblyContext);
  if (context === undefined) {
    throw new Error('useAssembly must be used within an AssemblyProvider');
  }
  return context;
};
