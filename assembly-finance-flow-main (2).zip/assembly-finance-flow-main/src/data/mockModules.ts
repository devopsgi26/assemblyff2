
import { ModuleData } from '@/types/module';

export const mockModules: ModuleData[] = [
  {
    id: 'module-1',
    name: 'Transfer Module',
    description: 'Standard wafer transfer system with high precision handling',
    basePrice: 5000,
    costs: {
      engineering: 12500,
      manufacturing: 18750,
      bom: 24000,
    },
    compatibility: {
      compatibleModules: ['module-2', 'module-4'],
      incompatibleModules: ['module-3'],
    },
    media: {
      imageUrl: 'https://images.unsplash.com/photo-1518770660439-4636190af475',
    },
  },
  {
    id: 'module-2',
    name: 'Vacuum Chamber',
    description: 'High-performance vacuum chamber with pressure control',
    basePrice: 8000,
    costs: {
      engineering: 18000,
      manufacturing: 25000,
      bom: 35000,
    },
    compatibility: {
      compatibleModules: ['module-1', 'module-4', 'module-5'],
      incompatibleModules: [],
    },
    media: {
      imageUrl: 'https://images.unsplash.com/photo-1581091226825-a6a2a5aee158',
    },
  },
  {
    id: 'module-3',
    name: 'Processing Unit',
    description: 'Multi-function processing unit for semiconductor etching',
    basePrice: 12000,
    costs: {
      engineering: 22500,
      manufacturing: 31000,
      bom: 42000,
    },
    compatibility: {
      compatibleModules: ['module-5', 'module-6'],
      incompatibleModules: ['module-1'],
    },
    media: {
      imageUrl: 'https://images.unsplash.com/photo-1605810230434-7631ac76ec81',
    },
  },
  {
    id: 'module-4',
    name: 'Cooling System',
    description: 'Advanced temperature control for process stability',
    basePrice: 3500,
    costs: {
      engineering: 9500,
      manufacturing: 14000,
      bom: 18500,
    },
    compatibility: {
      compatibleModules: ['module-1', 'module-2', 'module-5', 'module-6'],
      incompatibleModules: [],
    },
    media: {
      imageUrl: 'https://images.unsplash.com/photo-1487058792275-0ad4aaf24ca7',
    },
  },
  {
    id: 'module-5',
    name: 'Control System',
    description: 'Integrated control system with advanced UI',
    basePrice: 6500,
    costs: {
      engineering: 14500,
      manufacturing: 8000,
      bom: 22000,
    },
    compatibility: {
      compatibleModules: ['module-2', 'module-3', 'module-4'],
      incompatibleModules: [],
    },
    media: {
      imageUrl: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6',
    },
  },
  {
    id: 'module-6',
    name: 'Robot Arm',
    description: 'Precision robotic arm for wafer handling',
    basePrice: 9500,
    costs: {
      engineering: 17500,
      manufacturing: 24000,
      bom: 32000,
    },
    compatibility: {
      compatibleModules: ['module-3', 'module-4'],
      incompatibleModules: [],
    },
    media: {
      imageUrl: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e',
    },
  },
];
