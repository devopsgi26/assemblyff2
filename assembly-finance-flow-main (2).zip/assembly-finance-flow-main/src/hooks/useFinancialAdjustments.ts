
import { useState } from 'react';
import { FinancialAdjustments } from '@/types/module';
import { useToast } from '@/hooks/use-toast';

const defaultFinancialAdjustments: FinancialAdjustments = {
  margin: 0.20, // 20%
  bankWarranty: 0.02, // 2%
  riskFactor: 0.05, // 5%
  adminFees: 0.03, // 3%
  rampUp: 0.04, // 4%
  currencyRisk: 0.02, // 2%
  currencyRate: 1, // 1:1 EUR
};

export const useFinancialAdjustments = () => {
  const [financialAdjustments, setFinancialAdjustments] = useState<FinancialAdjustments>(defaultFinancialAdjustments);
  const { toast } = useToast();

  const updateFinancialAdjustments = (adjustments: Partial<FinancialAdjustments>) => {
    try {
      if (!adjustments || typeof adjustments !== 'object') {
        throw new Error('Invalid financial adjustments data provided');
      }
      
      // Validate percentage values to prevent invalid inputs
      const validatedAdjustments = { ...adjustments };
      Object.entries(validatedAdjustments).forEach(([key, value]) => {
        if (key !== 'currencyRate' && (typeof value === 'number' && (value < 0 || value > 1))) {
          throw new Error(`${key} must be between 0 and 1 (0% to 100%)`);
        }
      });
      
      setFinancialAdjustments({ ...financialAdjustments, ...validatedAdjustments });
    } catch (error) {
      console.error('Failed to update financial adjustments:', error);
      toast({
        title: 'Update Failed',
        description: `${error instanceof Error ? error.message : 'Failed to update financial adjustments. Please try again.'}`,
        variant: 'destructive',
      });
    }
  };

  const resetFinancialAdjustments = () => {
    try {
      setFinancialAdjustments(defaultFinancialAdjustments);
    } catch (error) {
      console.error('Failed to reset financial adjustments:', error);
      toast({
        title: 'Reset Failed',
        description: 'Failed to reset financial adjustments. Please try again.',
        variant: 'destructive',
      });
    }
  };

  return {
    financialAdjustments,
    setFinancialAdjustments,
    updateFinancialAdjustments,
    resetFinancialAdjustments,
    defaultFinancialAdjustments
  };
};
