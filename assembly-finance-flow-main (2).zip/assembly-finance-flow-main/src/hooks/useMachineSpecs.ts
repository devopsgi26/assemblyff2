
import { useState } from 'react';
import { MachineSpecs } from '@/types/module';
import { useToast } from '@/hooks/use-toast';

const defaultMachineSpecs: MachineSpecs = {
  bodyType: '',
  productLine: '',
  waferSize: '',
  chamberCount: 1,
  axisSetup: '',
};

export const useMachineSpecs = () => {
  const [machineSpecs, setMachineSpecs] = useState<MachineSpecs>(defaultMachineSpecs);
  const { toast } = useToast();

  const updateMachineSpecs = (specs: Partial<MachineSpecs>) => {
    try {
      if (!specs || typeof specs !== 'object') {
        throw new Error('Invalid machine specifications provided');
      }
      
      setMachineSpecs({ ...machineSpecs, ...specs });
    } catch (error) {
      console.error('Failed to update machine specifications:', error);
      toast({
        title: 'Update Failed',
        description: 'Failed to update machine specifications. Please try again.',
        variant: 'destructive',
      });
    }
  };

  const resetMachineSpecs = () => {
    try {
      setMachineSpecs(defaultMachineSpecs);
    } catch (error) {
      console.error('Failed to reset machine specifications:', error);
      toast({
        title: 'Reset Failed',
        description: 'Failed to reset machine specifications. Please try again.',
        variant: 'destructive',
      });
    }
  };

  return {
    machineSpecs,
    setMachineSpecs,
    updateMachineSpecs,
    resetMachineSpecs,
    defaultMachineSpecs
  };
};
