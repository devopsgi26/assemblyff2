
import { useMemo } from 'react';
import { AssemblyModule, ModuleData } from '@/types/module';
import { mockModules } from '@/data/mockModules';

export interface ProcessCategory {
  id: string;
  name: string;
  description: string;
}

export const useModuleCategories = () => {
  const PROCESS_CATEGORIES: ProcessCategory[] = useMemo(() => [
    { id: 'assembly', name: 'Assembly', description: 'Machine assembly components' },
    { id: 'packaging', name: 'Packaging', description: 'Packaging and finishing modules' },
    { id: 'cutting', name: 'Cutting', description: 'Cutting and machining components' },
    { id: 'electronics', name: 'Electronics', description: 'Electronic control systems' }
  ], []);

  // Group modules by category
  const getModulesByCategory = (modules: AssemblyModule[], categoryId: string) => {
    // This is just a placeholder implementation
    // In a real app, modules would have a category field
    switch (categoryId) {
      case 'assembly':
        return modules.filter(m => m.id.includes('asm') || m.costs.manufacturing > m.costs.engineering);
      case 'packaging':
        return modules.filter(m => m.id.includes('pkg'));
      case 'cutting':
        return modules.filter(m => m.id.includes('cut') || m.costs.bom > 5000);
      case 'electronics':
        return modules.filter(m => m.id.includes('elec') || m.costs.engineering > m.costs.manufacturing);
      default:
        return modules.filter(m => !m.id.includes('asm') && !m.id.includes('pkg') && !m.id.includes('cut') && !m.id.includes('elec'));
    }
  };

  // Get available modules for a category
  const getAvailableModules = (selectedModules: AssemblyModule[], categoryId: string): AssemblyModule[] => {
    const selectedModuleIds = selectedModules.map(m => m.id);
    
    // Filter available modules based on category and not already selected
    return mockModules
      .filter(m => !selectedModuleIds.includes(m.id))
      .filter(m => {
        switch (categoryId) {
          case 'assembly':
            return m.id.includes('asm') || m.costs.manufacturing > m.costs.engineering;
          case 'packaging':
            return m.id.includes('pkg');
          case 'cutting':
            return m.id.includes('cut') || m.costs.bom > 5000;
          case 'electronics':
            return m.id.includes('elec') || m.costs.engineering > m.costs.manufacturing;
          default:
            return !m.id.includes('asm') && !m.id.includes('pkg') && !m.id.includes('cut') && !m.id.includes('elec');
        }
      })
      // Convert ModuleData to AssemblyModule by adding quantity property
      .map(module => ({
        ...module,
        quantity: 1  // Default quantity for available modules
      }));
  };

  return {
    categories: PROCESS_CATEGORIES,
    getModulesByCategory,
    getAvailableModules
  };
};
