
import { useCallback } from 'react';
import { AssemblyModule } from '@/types/module';
import { useToast } from '@/hooks/use-toast';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { v4 as uuidv4 } from 'uuid';
import { 
  addOrUpdateModule, 
  removeModule as removeModuleUtil, 
  updateModuleQuantity as updateQuantityUtil, 
  updateModule as updateModuleUtil, 
  reorderModules as reorderModulesUtil,
  deleteAvailableModule as deleteAvailableModuleUtil 
} from '@/utils/moduleOperations';
import {
  getCategoryCosts as getCategoryCostsUtil,
  getModulesByCategory as getModulesByCategoryUtil,
  checkModuleCompatibility
} from '@/utils/moduleUtils';

export const useModules = () => {
  const [modules, setModules] = useLocalStorage<AssemblyModule[]>('assemblyModules', []);
  const [availableModules, setAvailableModules] = useLocalStorage<AssemblyModule[]>('availableModules', []);
  const { toast } = useToast();

  // Create a new module
  const createModule = useCallback((moduleData: Omit<AssemblyModule, 'id'>): AssemblyModule | null => {
    try {
      // Generate a unique ID for the new module
      const newModule: AssemblyModule = {
        ...moduleData,
        id: uuidv4(),
        quantity: moduleData.quantity || 1
      };
      
      // Add to available modules
      const updatedAvailableModules = [...availableModules, newModule];
      setAvailableModules(updatedAvailableModules);
      
      toast({
        title: 'Module Created',
        description: `${newModule.name} has been added to your module library.`,
      });
      
      return newModule;
    } catch (error) {
      console.error('Failed to create module:', error);
      toast({
        title: 'Creation Failed',
        description: `${error instanceof Error ? error.message : 'Failed to create module. Please try again.'}`,
        variant: 'destructive',
      });
      return null;
    }
  }, [availableModules, setAvailableModules, toast]);

  // Add a module to the assembly
  const addModule = useCallback((module: AssemblyModule) => {
    try {
      // Check module compatibility with existing modules
      const isCompatible = checkModuleCompatibility(module, modules);
      if (!isCompatible) {
        throw new Error('This module is incompatible with your current assembly.');
      }
      
      const updatedModules = addOrUpdateModule(modules, module);
      setModules(updatedModules);
      
      toast({
        title: 'Module Added',
        description: `${module.name} has been added to your assembly.`,
      });
    } catch (error) {
      console.error('Failed to add module:', error);
      toast({
        title: 'Add Failed',
        description: `${error instanceof Error ? error.message : 'Failed to add module. Please try again.'}`,
        variant: 'destructive',
      });
    }
  }, [modules, setModules, toast]);

  // Remove a module from the assembly
  const removeModule = useCallback((moduleId: string) => {
    try {
      const updatedModules = removeModuleUtil(modules, moduleId);
      setModules(updatedModules);
      
      toast({
        title: 'Module Removed',
        description: 'The module has been removed from your assembly.',
      });
    } catch (error) {
      console.error('Failed to remove module:', error);
      toast({
        title: 'Remove Failed',
        description: `${error instanceof Error ? error.message : 'Failed to remove module. Please try again.'}`,
        variant: 'destructive',
      });
    }
  }, [modules, setModules, toast]);

  // Update module quantity
  const updateModuleQuantity = useCallback((moduleId: string, quantity: number) => {
    try {
      const updatedModules = updateQuantityUtil(modules, moduleId, quantity);
      setModules(updatedModules);
      
      toast({
        title: 'Quantity Updated',
        description: 'The module quantity has been updated.',
      });
    } catch (error) {
      console.error('Failed to update module quantity:', error);
      toast({
        title: 'Update Failed',
        description: `${error instanceof Error ? error.message : 'Failed to update module quantity. Please try again.'}`,
        variant: 'destructive',
      });
    }
  }, [modules, setModules, toast]);

  // Update module properties
  const updateModule = useCallback((moduleId: string, updates: Partial<AssemblyModule>) => {
    try {
      // First, check if this module exists in the active modules
      const moduleInActive = modules.find(m => m.id === moduleId);
      
      // Update in active modules if it exists there
      if (moduleInActive) {
        const updatedModules = updateModuleUtil(modules, moduleId, updates);
        setModules(updatedModules);
      }
      
      // Also update the module in available modules if it exists there
      const moduleInAvailable = availableModules.find(m => m.id === moduleId);
      if (moduleInAvailable) {
        const updatedAvailableModules = updateModuleUtil(availableModules, moduleId, updates);
        setAvailableModules(updatedAvailableModules);
      }
      
      if (moduleInActive || moduleInAvailable) {
        toast({
          title: 'Module Updated',
          description: 'The module has been successfully updated.',
        });
      } else {
        throw new Error('Module not found in any collection');
      }
    } catch (error) {
      console.error('Failed to update module:', error);
      toast({
        title: 'Update Failed',
        description: `${error instanceof Error ? error.message : 'Failed to update module. Please try again.'}`,
        variant: 'destructive',
      });
    }
  }, [modules, availableModules, setModules, setAvailableModules, toast]);
  
  // Delete a module from available modules
  const deleteAvailableModule = useCallback((moduleId: string) => {
    try {
      // Check if the module is currently in use
      const moduleInUse = modules.some(m => m.id === moduleId);
      if (moduleInUse) {
        throw new Error('Cannot delete a module that is currently in use.');
      }
      
      const updatedAvailableModules = deleteAvailableModuleUtil(availableModules, moduleId);
      setAvailableModules(updatedAvailableModules);
      
      toast({
        title: 'Module Deleted',
        description: 'The module has been removed from the library.',
      });
    } catch (error) {
      console.error('Failed to delete module:', error);
      toast({
        title: 'Delete Failed',
        description: `${error instanceof Error ? error.message : 'Failed to delete module. Please try again.'}`,
        variant: 'destructive',
      });
    }
  }, [modules, availableModules, setAvailableModules, toast]);
  
  // Reorder modules
  const reorderModules = useCallback((sourceId: string, targetId: string) => {
    try {
      const updatedModules = reorderModulesUtil(modules, sourceId, targetId);
      setModules(updatedModules);
    } catch (error) {
      console.error('Failed to reorder modules:', error);
      toast({
        title: 'Reorder Failed',
        description: `${error instanceof Error ? error.message : 'Failed to reorder modules. Please try again.'}`,
        variant: 'destructive',
      });
    }
  }, [modules, setModules, toast]);
  
  // Reorder available modules
  const reorderAvailableModules = useCallback((sourceId: string, targetId: string) => {
    try {
      const updatedModules = reorderModulesUtil(availableModules, sourceId, targetId);
      setAvailableModules(updatedModules);
    } catch (error) {
      console.error('Failed to reorder available modules:', error);
      toast({
        title: 'Reorder Failed',
        description: `${error instanceof Error ? error.message : 'Failed to reorder available modules. Please try again.'}`,
        variant: 'destructive',
      });
    }
  }, [availableModules, setAvailableModules, toast]);

  // Group modules by process category
  const getModulesByCategory = useCallback(() => {
    return getModulesByCategoryUtil(modules);
  }, [modules]);

  // Calculate category costs
  const getCategoryCosts = useCallback(() => {
    return getCategoryCostsUtil(modules);
  }, [modules]);

  return {
    modules,
    setModules,
    availableModules,
    setAvailableModules,
    addModule,
    removeModule,
    updateModuleQuantity,
    updateModule,
    createModule,
    deleteAvailableModule,
    reorderModules,
    reorderAvailableModules,
    getModulesByCategory,
    getCategoryCosts
  };
};
