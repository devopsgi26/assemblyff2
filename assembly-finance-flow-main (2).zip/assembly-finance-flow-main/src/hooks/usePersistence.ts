
import { useEffect } from 'react';
import { AssemblyModule, MachineSpecs, FinancialAdjustments, SavedAssembly, TravelCost } from '@/types/module';
import { useToast } from '@/hooks/use-toast';

interface PersistenceProps {
  modules: AssemblyModule[];
  machineSpecs: MachineSpecs;
  financialAdjustments: FinancialAdjustments;
  travelCosts: TravelCost[];
  savedAssemblies: SavedAssembly[];
  setModules: (modules: AssemblyModule[]) => void;
  setMachineSpecs: (specs: MachineSpecs) => void;
  setFinancialAdjustments: (adjustments: FinancialAdjustments) => void;
  setTravelCosts: (costs: TravelCost[]) => void;
  setSavedAssemblies: (assemblies: SavedAssembly[]) => void;
}

export const usePersistence = ({
  modules,
  machineSpecs,
  financialAdjustments,
  travelCosts,
  savedAssemblies,
  setModules,
  setMachineSpecs,
  setFinancialAdjustments,
  setTravelCosts,
  setSavedAssemblies
}: PersistenceProps) => {
  const { toast } = useToast();
  const STORAGE_KEY = 'engineeringApp';

  // Load saved data from localStorage
  useEffect(() => {
    try {
      const savedData = localStorage.getItem(STORAGE_KEY);
      if (!savedData) return;
      
      const parsedData = JSON.parse(savedData);
      
      // Validate data structure before loading
      if (!parsedData) {
        throw new Error('Invalid saved data format');
      }
      
      // Check if the data has a valid structure
      if (parsedData.savedAssemblies && Array.isArray(parsedData.savedAssemblies)) {
        setSavedAssemblies(parsedData.savedAssemblies);
      }
      
      // Load current session if it exists
      if (parsedData.currentSession) {
        const { modules, machineSpecs, financialAdjustments, travelCosts } = parsedData.currentSession;
        
        if (modules && Array.isArray(modules)) setModules(modules);
        if (machineSpecs && typeof machineSpecs === 'object') setMachineSpecs(machineSpecs);
        if (financialAdjustments && typeof financialAdjustments === 'object') setFinancialAdjustments(financialAdjustments);
        if (travelCosts && Array.isArray(travelCosts)) setTravelCosts(travelCosts);
      }
      
      console.log('Session data loaded successfully');
    } catch (error) {
      console.error('Failed to load data from localStorage:', error);
      toast({
        title: 'Data Loading Error',
        description: 'Failed to load your previous session data. Starting with a fresh session.',
        variant: 'destructive',
      });
    }
  }, []);

  // Save data to localStorage whenever it changes
  useEffect(() => {
    try {
      const dataToSave = {
        currentSession: {
          modules,
          machineSpecs,
          financialAdjustments,
          travelCosts,
        },
        savedAssemblies,
      };
      
      localStorage.setItem(STORAGE_KEY, JSON.stringify(dataToSave));
    } catch (error) {
      console.error('Failed to save data to localStorage:', error);
      toast({
        title: 'Data Saving Error',
        description: 'Failed to save your current session data. Your changes might not persist between sessions.',
        variant: 'destructive',
      });
    }
  }, [modules, machineSpecs, financialAdjustments, travelCosts, savedAssemblies]);
  
  // Provide methods to manually handle persistence
  const forceSave = () => {
    try {
      const dataToSave = {
        currentSession: {
          modules,
          machineSpecs,
          financialAdjustments,
          travelCosts,
        },
        savedAssemblies,
      };
      
      localStorage.setItem(STORAGE_KEY, JSON.stringify(dataToSave));
      
      toast({
        title: 'Data Saved',
        description: 'Your session data has been manually saved.',
      });
      
      return true;
    } catch (error) {
      console.error('Failed to manually save data:', error);
      toast({
        title: 'Manual Save Failed',
        description: 'Failed to manually save your session data.',
        variant: 'destructive',
      });
      
      return false;
    }
  };
  
  const clearPersistedData = () => {
    try {
      localStorage.removeItem(STORAGE_KEY);
      toast({
        title: 'Data Cleared',
        description: 'All persisted data has been cleared.',
      });
      
      return true;
    } catch (error) {
      console.error('Failed to clear persisted data:', error);
      toast({
        title: 'Clear Data Failed',
        description: 'Failed to clear persisted data.',
        variant: 'destructive',
      });
      
      return false;
    }
  };

  return {
    forceSave,
    clearPersistedData,
  };
};
