
import { useState } from 'react';
import { SavedAssembly, AssemblyModule, MachineSpecs, FinancialAdjustments, TravelCost } from '@/types/module';
import { useToast } from '@/hooks/use-toast';

export const useSavedAssemblies = (
  modules: AssemblyModule[],
  machineSpecs: MachineSpecs,
  financialAdjustments: FinancialAdjustments,
  travelCosts: TravelCost[],
  setModules: (modules: AssemblyModule[]) => void,
  setMachineSpecs: (specs: MachineSpecs) => void,
  setFinancialAdjustments: (adjustments: FinancialAdjustments) => void,
  setTravelCosts: (costs: TravelCost[]) => void
) => {
  const [savedAssemblies, setSavedAssemblies] = useState<SavedAssembly[]>([]);
  const { toast } = useToast();

  const saveAssembly = (name: string) => {
    try {
      if (!name || typeof name !== 'string' || name.trim() === '') {
        throw new Error('Assembly name is required');
      }
      
      // Check for duplicates
      const duplicateNameAssembly = savedAssemblies.find(a => a.name.toLowerCase() === name.toLowerCase());
      if (duplicateNameAssembly) {
        throw new Error('An assembly with this name already exists');
      }
      
      if (modules.length === 0) {
        throw new Error('Cannot save an empty assembly. Please add at least one module');
      }
      
      const now = new Date().toISOString();
      const newAssembly: SavedAssembly = {
        id: `assembly-${Date.now()}`,
        name,
        createdAt: now,
        updatedAt: now,
        modules: [...modules],
        specs: { ...machineSpecs },
        financialAdjustments: { ...financialAdjustments },
        travelCosts: [...travelCosts],
      };
      
      setSavedAssemblies([...savedAssemblies, newAssembly]);
      
      toast({
        title: 'Assembly Saved',
        description: `'${name}' has been saved successfully.`,
      });
    } catch (error) {
      console.error('Failed to save assembly:', error);
      toast({
        title: 'Save Failed',
        description: `${error instanceof Error ? error.message : 'Failed to save assembly. Please try again.'}`,
        variant: 'destructive',
      });
    }
  };

  const loadAssembly = (assemblyId: string) => {
    try {
      if (!assemblyId) {
        throw new Error('Invalid assembly ID provided');
      }
      
      const assembly = savedAssemblies.find(a => a.id === assemblyId);
      if (!assembly) {
        throw new Error('Could not find the requested assembly');
      }
      
      setModules([...assembly.modules]);
      setMachineSpecs({ ...assembly.specs });
      setFinancialAdjustments({ ...assembly.financialAdjustments });
      setTravelCosts([...assembly.travelCosts]);
      
      toast({
        title: 'Assembly Loaded',
        description: `'${assembly.name}' has been loaded successfully.`,
      });
    } catch (error) {
      console.error('Failed to load assembly:', error);
      toast({
        title: 'Load Failed',
        description: `${error instanceof Error ? error.message : 'Could not find the requested assembly.'}`,
        variant: 'destructive',
      });
    }
  };

  const deleteAssembly = (assemblyId: string) => {
    try {
      if (!assemblyId) {
        throw new Error('Invalid assembly ID provided');
      }
      
      const assemblyToDelete = savedAssemblies.find(a => a.id === assemblyId);
      if (!assemblyToDelete) {
        throw new Error('Could not find the assembly to delete');
      }
      
      setSavedAssemblies(savedAssemblies.filter(a => a.id !== assemblyId));
      
      toast({
        title: 'Assembly Deleted',
        description: `'${assemblyToDelete.name}' has been deleted.`,
      });
    } catch (error) {
      console.error('Failed to delete assembly:', error);
      toast({
        title: 'Delete Failed',
        description: `${error instanceof Error ? error.message : 'Failed to delete assembly. Please try again.'}`,
        variant: 'destructive',
      });
    }
  };

  return {
    savedAssemblies,
    setSavedAssemblies,
    saveAssembly,
    loadAssembly,
    deleteAssembly,
  };
};
