
import { useState } from 'react';
import { TravelCost } from '@/types/module';
import { useToast } from '@/hooks/use-toast';

export const useTravelCosts = () => {
  const [travelCosts, setTravelCosts] = useState<TravelCost[]>([]);
  const { toast } = useToast();

  const addTravelCost = (cost: TravelCost) => {
    try {
      if (!cost || typeof cost !== 'object') {
        throw new Error('Invalid travel cost data provided');
      }
      
      setTravelCosts([...travelCosts, cost]);
      toast({
        title: 'Travel Cost Added',
        description: 'The travel cost has been added successfully.',
      });
    } catch (error) {
      console.error('Failed to add travel cost:', error);
      toast({
        title: 'Add Failed',
        description: 'Failed to add travel cost. Please check your input data and try again.',
        variant: 'destructive',
      });
    }
  };

  const updateTravelCost = (index: number, cost: Partial<TravelCost>) => {
    try {
      if (index < 0 || index >= travelCosts.length) {
        throw new Error('Invalid travel cost index');
      }
      
      if (!cost || typeof cost !== 'object') {
        throw new Error('Invalid travel cost data provided');
      }
      
      const updatedCosts = [...travelCosts];
      updatedCosts[index] = { ...updatedCosts[index], ...cost };
      setTravelCosts(updatedCosts);
    } catch (error) {
      console.error('Failed to update travel cost:', error);
      toast({
        title: 'Update Failed',
        description: 'Failed to update travel cost. Please try again.',
        variant: 'destructive',
      });
    }
  };

  const removeTravelCost = (index: number) => {
    try {
      if (index < 0 || index >= travelCosts.length) {
        throw new Error('Invalid travel cost index');
      }
      
      const updatedCosts = [...travelCosts];
      updatedCosts.splice(index, 1);
      setTravelCosts(updatedCosts);
      toast({
        title: 'Travel Cost Removed',
        description: 'The travel cost has been removed successfully.',
      });
    } catch (error) {
      console.error('Failed to remove travel cost:', error);
      toast({
        title: 'Remove Failed',
        description: 'Failed to remove travel cost. Please try again.',
        variant: 'destructive',
      });
    }
  };

  const resetTravelCosts = () => {
    try {
      setTravelCosts([]);
    } catch (error) {
      console.error('Failed to reset travel costs:', error);
      toast({
        title: 'Reset Failed',
        description: 'Failed to reset travel costs. Please try again.',
        variant: 'destructive',
      });
    }
  };

  return {
    travelCosts,
    setTravelCosts,
    addTravelCost,
    updateTravelCost,
    removeTravelCost,
    resetTravelCosts
  };
};
