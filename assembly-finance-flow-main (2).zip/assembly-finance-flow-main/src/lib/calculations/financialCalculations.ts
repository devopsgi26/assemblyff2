
import { FinancialAdjustments, AssemblyModule, TravelCost } from '@/types/module';
import { roundToDecimal, addPercentage } from '@/utils/rounding';

/**
 * Calculate the base cost of all modules
 */
export const calculateBaseModuleCost = (modules: AssemblyModule[]): number => {
  return modules.reduce((total, module) => {
    const moduleCost = module.costs.engineering + module.costs.manufacturing + module.costs.bom;
    return total + (moduleCost * module.quantity);
  }, 0);
};

/**
 * Calculate engineering costs
 */
export const calculateEngineeringCosts = (modules: AssemblyModule[]): number => {
  return modules.reduce((total, module) => {
    return total + (module.costs.engineering * module.quantity);
  }, 0);
};

/**
 * Calculate manufacturing costs
 */
export const calculateManufacturingCosts = (modules: AssemblyModule[]): number => {
  return modules.reduce((total, module) => {
    return total + (module.costs.manufacturing * module.quantity);
  }, 0);
};

/**
 * Calculate BOM costs
 */
export const calculateBOMCosts = (modules: AssemblyModule[]): number => {
  return modules.reduce((total, module) => {
    return total + (module.costs.bom * module.quantity);
  }, 0);
};

/**
 * Calculate total travel costs
 */
export const calculateTravelCosts = (travelCosts: TravelCost[]): number => {
  return travelCosts.reduce((total, cost) => {
    const personnelCost = 
      (cost.standardTime * 85) + 
      (cost.overtimeHours * 125) + 
      (cost.premiumTimeHours * 170) + 
      (cost.travelTime * 65);
    
    const expenseCost = cost.carExpenses + cost.hotel + cost.allowance;
    
    return total + personnelCost + expenseCost;
  }, 0);
};

/**
 * Calculate logistics costs (simplified as percentage of BOM)
 */
export const calculateLogisticsCosts = (modules: AssemblyModule[]): number => {
  const bomCost = calculateBOMCosts(modules);
  return bomCost * 0.08; // 8% of BOM costs
};

/**
 * Calculate total base cost before adjustments
 */
export const calculateTotalBaseCost = (
  modules: AssemblyModule[],
  travelCosts: TravelCost[]
): number => {
  const moduleCost = calculateBaseModuleCost(modules);
  const travelCost = calculateTravelCosts(travelCosts);
  const logisticsCost = calculateLogisticsCosts(modules);
  
  return moduleCost + travelCost + logisticsCost;
};

/**
 * Apply financial adjustments to base cost
 */
export const applyFinancialAdjustments = (
  baseCost: number,
  adjustments: FinancialAdjustments
): number => {
  let adjustedCost = baseCost;
  
  // Apply risk factor
  adjustedCost = addPercentage(adjustedCost, adjustments.riskFactor);
  
  // Apply admin fees
  adjustedCost = addPercentage(adjustedCost, adjustments.adminFees);
  
  // Apply ramp up
  adjustedCost = addPercentage(adjustedCost, adjustments.rampUp);
  
  // Apply bank warranty
  adjustedCost = addPercentage(adjustedCost, adjustments.bankWarranty);
  
  // Apply currency risk
  adjustedCost = addPercentage(adjustedCost, adjustments.currencyRisk);
  
  // Apply margin (intentionally after other adjustments)
  adjustedCost = addPercentage(adjustedCost, adjustments.margin);
  
  return roundToDecimal(adjustedCost);
};

/**
 * Calculate the full system price with all adjustments
 */
export const calculateSystemPrice = (
  modules: AssemblyModule[],
  travelCosts: TravelCost[],
  adjustments: FinancialAdjustments
): number => {
  const baseCost = calculateTotalBaseCost(modules, travelCosts);
  return applyFinancialAdjustments(baseCost, adjustments);
};

/**
 * Get detailed cost breakdown
 */
export const getDetailedCostBreakdown = (
  modules: AssemblyModule[],
  travelCosts: TravelCost[],
  adjustments: FinancialAdjustments
) => {
  const engineeringCost = calculateEngineeringCosts(modules);
  const manufacturingCost = calculateManufacturingCosts(modules);
  const bomCost = calculateBOMCosts(modules);
  const travelCost = calculateTravelCosts(travelCosts);
  const logisticsCost = calculateLogisticsCosts(modules);
  
  const baseCost = engineeringCost + manufacturingCost + bomCost + travelCost + logisticsCost;
  
  const riskAmount = baseCost * adjustments.riskFactor;
  const adminAmount = baseCost * adjustments.adminFees;
  const rampUpAmount = baseCost * adjustments.rampUp;
  const warrantyAmount = baseCost * adjustments.bankWarranty;
  const currencyRiskAmount = baseCost * adjustments.currencyRisk;
  
  const subtotalBeforeMargin = baseCost + riskAmount + adminAmount + rampUpAmount + warrantyAmount + currencyRiskAmount;
  
  const marginAmount = subtotalBeforeMargin * adjustments.margin;
  const totalPrice = subtotalBeforeMargin + marginAmount;
  
  const convertedPrice = totalPrice * adjustments.currencyRate;
  
  return {
    baseCosts: {
      engineering: roundToDecimal(engineeringCost),
      manufacturing: roundToDecimal(manufacturingCost),
      bom: roundToDecimal(bomCost),
      travel: roundToDecimal(travelCost),
      logistics: roundToDecimal(logisticsCost),
      total: roundToDecimal(baseCost),
    },
    adjustments: {
      riskFactor: roundToDecimal(riskAmount),
      adminFees: roundToDecimal(adminAmount),
      rampUp: roundToDecimal(rampUpAmount),
      bankWarranty: roundToDecimal(warrantyAmount),
      currencyRisk: roundToDecimal(currencyRiskAmount),
      margin: roundToDecimal(marginAmount),
    },
    totals: {
      subtotalBeforeMargin: roundToDecimal(subtotalBeforeMargin),
      totalPrice: roundToDecimal(totalPrice),
      convertedPrice: roundToDecimal(convertedPrice),
    }
  };
};
