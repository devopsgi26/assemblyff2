import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import MainLayout from '@/components/layout/MainLayout';
import { useAssembly } from '@/context/AssemblyContext';
import { useToast } from '@/hooks/use-toast';
import { useNavigate } from 'react-router-dom';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import { useAuth } from '@/context/AuthContext';
import { UserAction } from '@/types/module';
import { exportToPdf, exportToWord } from '@/utils/exportUtils';

// Import refactored components
import MetadataDisplay from '@/components/metadata/MetadataDisplay';
import ExportDialog from '@/components/calculator/ExportDialog';
import SaveAssemblyDialog from '@/components/calculator/SaveAssemblyDialog';
import CalculatorToolbar from '@/components/calculator/CalculatorToolbar';
import CalculatorContent from '@/components/calculator/CalculatorContent';

const Calculator: React.FC = () => {
  const { 
    modules, 
    financialAdjustments, 
    travelCosts, 
    updateFinancialAdjustments,
    addTravelCost,
    updateTravelCost,
    removeTravelCost,
    saveAssembly,
    updateModule,
    removeModule,
    reorderModules
  } = useAssembly();

  const [isExportDialogOpen, setIsExportDialogOpen] = useState(false);
  const [isSaveDialogOpen, setIsSaveDialogOpen] = useState(false);
  const [assemblyName, setAssemblyName] = useState('');
  const [rates, setRates] = useState({
    engineeringRate: 85,
    manufacturingRate: 65,
    installationRate: 95,
    logisticsRate: 8 // percentage of BOM
  });
  
  const [metadataVisible, setMetadataVisible] = useState(false);
  const [moduleHistory, setModuleHistory] = useState<UserAction[]>([]);
  const [exportFormat, setExportFormat] = useState<'summary'|'pdf'|'word'>('summary');
  
  const { toast } = useToast();
  const navigate = useNavigate();
  const { user, hasPermission } = useAuth();
  const isAdminOrManager = hasPermission('editFinancials') || hasPermission('viewMetadata');

  // Load saved rates from localStorage
  useEffect(() => {
    const savedRates = localStorage.getItem('calculatorRates');
    if (savedRates) {
      try {
        setRates(JSON.parse(savedRates));
      } catch (e) {
        console.error('Failed to parse saved rates:', e);
      }
    }
  }, []);

  // Save rates to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('calculatorRates', JSON.stringify(rates));
  }, [rates]);

  // Function to add actions to audit trail
  const addHistoryAction = (actionType: string, details: Record<string, any>) => {
    const action: UserAction = {
      actionType,
      userId: user?.id || 'unknown',
      userName: user?.name || 'Unknown User',
      timestamp: new Date().toISOString(),
      details
    };
    
    setModuleHistory(prev => [action, ...prev].slice(0, 100)); // Keep last 100 actions
  };

  const handleExport = () => {
    setExportFormat('summary');
    setIsExportDialogOpen(true);
  };

  const handleExportPdf = async () => {
    try {
      await exportToPdf('calculator-content', 'system-price-summary');
      addHistoryAction('EXPORT_PDF', { format: 'PDF', timestamp: new Date().toISOString() });
      toast({
        title: 'Export Complete',
        description: 'System price summary has been exported to PDF successfully.',
      });
    } catch (error) {
      console.error('PDF export error:', error);
      toast({
        title: 'Export Failed',
        description: 'Failed to export to PDF. Please try again.',
        variant: 'destructive',
      });
    }
  };

  const handleExportWord = async () => {
    try {
      exportToWord('calculator-content', 'system-price-summary');
      addHistoryAction('EXPORT_WORD', { format: 'Word', timestamp: new Date().toISOString() });
      toast({
        title: 'Export Complete',
        description: 'System price summary has been exported to Word successfully.',
      });
    } catch (error) {
      console.error('Word export error:', error);
      toast({
        title: 'Export Failed',
        description: 'Failed to export to Word. Please try again.',
        variant: 'destructive',
      });
    }
  };

  const handleSaveAssembly = () => {
    if (!assemblyName.trim()) {
      toast({
        title: 'Name Required',
        description: 'Please enter a name for your assembly.',
        variant: 'destructive',
      });
      return;
    }
    
    saveAssembly(assemblyName);
    setIsSaveDialogOpen(false);
    setAssemblyName('');
    
    toast({
      title: 'Assembly Saved',
      description: `${assemblyName} has been saved successfully.`,
    });
    
    addHistoryAction('SAVE_ASSEMBLY', { assemblyName });
  };

  const handleExportConfirm = () => {
    let message: string;
    
    switch (exportFormat) {
      case 'pdf':
        handleExportPdf();
        break;
      case 'word':
        handleExportWord();
        break;
      default:
        message = 'System price summary has been exported successfully.';
        addHistoryAction('EXPORT', { format: 'Summary' });
        toast({
          title: 'Export Complete',
          description: message,
        });
    }
    
    setIsExportDialogOpen(false);
  };

  const handleEditConfigurationClick = () => {
    navigate('/configurator');
  };
  
  const handleUpdateModule = (moduleId: string, updates: Partial<typeof modules[0]>) => {
    updateModule(moduleId, updates);
    addHistoryAction('UPDATE_MODULE', { moduleId, updates, timestamp: new Date().toISOString() });
  };

  const handleRemoveModule = (moduleId: string) => {
    const moduleName = modules.find(m => m.id === moduleId)?.name || 'Unknown';
    removeModule(moduleId);
    addHistoryAction('REMOVE_MODULE', { moduleId, moduleName, timestamp: new Date().toISOString() });
  };

  const handleReorderModules = (sourceId: string, targetId: string) => {
    reorderModules(sourceId, targetId);
    addHistoryAction('REORDER_MODULES', { sourceId, targetId, timestamp: new Date().toISOString() });
  };

  // Add proper rates update handler
  const handleRatesChange = (partialRates: Partial<typeof rates>) => {
    setRates(prevRates => ({
      ...prevRates,
      ...partialRates
    }));
    addHistoryAction('UPDATE_RATES', { rateChanges: partialRates, timestamp: new Date().toISOString() });
  };

  return (
    <DndProvider backend={HTML5Backend}>
      <MainLayout>
        <div className="space-y-6" id="calculator-content">
          <CalculatorToolbar
            isAdminOrManager={isAdminOrManager}
            metadataVisible={metadataVisible}
            onToggleMetadata={() => setMetadataVisible(!metadataVisible)}
            onSaveClick={() => setIsSaveDialogOpen(true)}
            onEditConfigurationClick={handleEditConfigurationClick}
          />

          <CalculatorContent
            modules={modules}
            financialAdjustments={financialAdjustments}
            travelCosts={travelCosts}
            rates={rates}
            onUpdateModule={handleUpdateModule}
            onRemoveModule={handleRemoveModule}
            onReorderModules={handleReorderModules}
            onAddTravelCost={addTravelCost}
            onUpdateTravelCost={updateTravelCost}
            onRemoveTravelCost={removeTravelCost}
            onExport={handleExport}
            onExportPdf={handleExportPdf}
            onExportWord={handleExportWord}
            onFinancialAdjustmentsChange={updateFinancialAdjustments}
            onRatesChange={handleRatesChange}
            onEditConfigurationClick={handleEditConfigurationClick}
          />

          <MetadataDisplay
            moduleHistory={moduleHistory}
            isVisible={metadataVisible}
            isAdminOrManager={isAdminOrManager}
          />
        </div>

        <ExportDialog
          isOpen={isExportDialogOpen}
          onOpenChange={setIsExportDialogOpen}
          onExport={handleExportConfirm}
          isAdminOrManager={isAdminOrManager}
        />

        <SaveAssemblyDialog
          isOpen={isSaveDialogOpen}
          onOpenChange={setIsSaveDialogOpen}
          assemblyName={assemblyName}
          onAssemblyNameChange={setAssemblyName}
          onSave={handleSaveAssembly}
        />
      </MainLayout>
    </DndProvider>
  );
};

export default Calculator;
