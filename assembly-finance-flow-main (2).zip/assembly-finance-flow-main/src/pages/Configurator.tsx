
import React, { useState } from 'react';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import MainLayout from '@/components/layout/MainLayout';
import { useAssembly } from '@/context/AssemblyContext';
import { AssemblyModule } from '@/types/module';
import ConfiguratorHeader from '@/components/machineAssembly/ConfiguratorHeader';
import ConfiguratorTabs from '@/components/machineAssembly/ConfiguratorTabs';
import SaveAssemblyDialog from '@/components/machineAssembly/SaveAssemblyDialog';
import ModuleEditDialog from '@/components/machineAssembly/ModuleEditDialog';
import { useModuleCategories } from '@/hooks/useModuleCategories';
import { useToast } from '@/hooks/use-toast';

const Configurator: React.FC = () => {
  const { 
    modules, 
    availableModules,
    machineSpecs, 
    updateMachineSpecs, 
    addModule, 
    removeModule, 
    updateModuleQuantity, 
    updateModule,
    createModule,
    deleteAvailableModule,
    reorderModules, 
    reorderAvailableModules,
    saveAssembly 
  } = useAssembly();
  
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('configuration');
  const [editingModule, setEditingModule] = useState<AssemblyModule | null>(null);
  const { toast } = useToast();
  const { categories, getModulesByCategory, getAvailableModules } = useModuleCategories();

  const handleAddModule = (module: AssemblyModule) => {
    addModule(module);
  };

  const handleRemoveModule = (moduleId: string) => {
    removeModule(moduleId);
  };

  const handleDeleteAvailableModule = (moduleId: string) => {
    deleteAvailableModule(moduleId);
  };

  const handleQuantityChange = (moduleId: string, quantity: number) => {
    updateModuleQuantity(moduleId, quantity);
  };

  const handleSaveAssembly = (assemblyName: string) => {
    saveAssembly(assemblyName);
    toast({
      title: 'Assembly Saved',
      description: `Your assembly "${assemblyName}" has been saved successfully.`,
    });
  };

  const handleCreateModule = (moduleData: Omit<AssemblyModule, 'id'>) => {
    const newModule = createModule(moduleData);
    if (newModule) {  // Now this is type-safe because createModule returns AssemblyModule | null
      setEditingModule(newModule);
    }
  };

  const handleEditModule = (moduleId: string) => {
    // Check in both active modules and available modules
    const moduleToEdit = modules.find(m => m.id === moduleId) || 
                         availableModules.find(m => m.id === moduleId);
    
    if (moduleToEdit) {
      setEditingModule(moduleToEdit);
    } else {
      console.error(`Module with ID ${moduleId} not found`);
    }
  };

  const handleSaveModuleEdit = (updatedModule: AssemblyModule) => {
    updateModule(updatedModule.id, updatedModule);
    setEditingModule(null);
    toast({
      title: 'Module Updated',
      description: `${updatedModule.name} has been updated successfully.`,
    });
  };

  const handleModuleReorder = (sourceId: string, targetId: string) => {
    // Check if both modules are in the active list
    const sourceInActive = modules.some(m => m.id === sourceId);
    const targetInActive = modules.some(m => m.id === targetId);
    
    // Check if both modules are in the available list
    const sourceInAvailable = availableModules.some(m => m.id === sourceId);
    const targetInAvailable = availableModules.some(m => m.id === targetId);
    
    if (sourceInActive && targetInActive) {
      // Reorder within active modules
      reorderModules(sourceId, targetId);
    } else if (sourceInAvailable && targetInAvailable) {
      // Reorder within available modules
      reorderAvailableModules(sourceId, targetId);
    }
    
    toast({
      title: 'Module Reordered',
      description: 'The module order has been updated.',
    });
  };

  // These adapter functions wrap the context methods to match component props
  const getCategoryModules = (categoryId: string) => {
    return getModulesByCategory(modules, categoryId);
  };

  const getAvailableCategoryModules = (categoryId: string) => {
    return getAvailableModules(availableModules, categoryId);
  };

  return (
    <DndProvider backend={HTML5Backend}>
      <MainLayout>
        <div className="space-y-6">
          <ConfiguratorHeader onSaveClick={() => setIsDialogOpen(true)} />

          <ConfiguratorTabs
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            machineSpecs={machineSpecs}
            updateMachineSpecs={updateMachineSpecs}
            categories={categories}
            modules={modules}
            availableModules={availableModules}
            getModulesByCategory={getCategoryModules}
            getAvailableModules={getAvailableCategoryModules}
            onAddModule={handleAddModule}
            onRemoveModule={handleRemoveModule}
            onUpdateQuantity={handleQuantityChange}
            onEditModule={handleEditModule}
            onCreateModule={handleCreateModule}
            onDeleteAvailableModule={handleDeleteAvailableModule}
            onReorderModules={handleModuleReorder}
          />
        </div>

        {/* Save Assembly Dialog */}
        <SaveAssemblyDialog 
          isOpen={isDialogOpen} 
          onOpenChange={setIsDialogOpen}
          onSave={handleSaveAssembly}
        />

        {/* Module Edit Dialog */}
        <ModuleEditDialog 
          module={editingModule}
          isOpen={!!editingModule}
          onClose={() => setEditingModule(null)}
          onSave={handleSaveModuleEdit}
          availableModules={[...modules, ...availableModules]}
        />
      </MainLayout>
    </DndProvider>
  );
};

export default Configurator;
