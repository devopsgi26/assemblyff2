
import React from 'react';
import { Link } from 'react-router-dom';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import MainLayout from '@/components/layout/MainLayout';
import { useAssembly } from '@/context/AssemblyContext';
import { formatCurrency } from '@/utils/rounding';
import { calculateSystemPrice } from '@/lib/calculations/financialCalculations';

const Dashboard: React.FC = () => {
  const { modules, machineSpecs, financialAdjustments, travelCosts, savedAssemblies } = useAssembly();
  
  // Calculate the current system price
  const systemPrice = calculateSystemPrice(modules, travelCosts, financialAdjustments);
  
  // Get the most recently updated assemblies
  const recentAssemblies = [...savedAssemblies]
    .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
    .slice(0, 3);

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
          <div className="flex space-x-2">
            <Link to="/configurator">
              <Button>Configure Machine</Button>
            </Link>
          </div>
        </div>

        {/* Overview Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Current Machine Card */}
          <Card>
            <CardContent className="p-6">
              <div className="flex justify-between items-center">
                <h3 className="font-medium">Current Machine</h3>
                <span className="text-sm text-gray-500">{modules.length} modules</span>
              </div>
              
              <div className="mt-2">
                {modules.length > 0 ? (
                  <>
                    <div className="text-2xl font-bold text-engineering-primary">
                      {formatCurrency(systemPrice)}
                    </div>
                    <div className="text-sm text-gray-500 mt-1">
                      {machineSpecs.bodyType || 'No'} {machineSpecs.productLine || 'body type'} - {machineSpecs.waferSize || 'No wafer size'}
                    </div>
                  </>
                ) : (
                  <div className="text-gray-500 py-4">
                    No active configuration
                  </div>
                )}
              </div>
              
              <div className="flex mt-4 space-x-2">
                <Link to="/configurator" className="flex-1">
                  <Button variant="outline" className="w-full" size="sm">
                    {modules.length > 0 ? 'Edit' : 'Create'} 
                  </Button>
                </Link>
                
                {modules.length > 0 && (
                  <Link to="/calculator" className="flex-1">
                    <Button variant="default" className="w-full" size="sm">
                      Calculate
                    </Button>
                  </Link>
                )}
              </div>
            </CardContent>
          </Card>
          
          {/* Saved Assemblies Card */}
          <Card>
            <CardContent className="p-6">
              <div className="flex justify-between items-center">
                <h3 className="font-medium">Saved Assemblies</h3>
                <span className="text-sm text-gray-500">{savedAssemblies.length} total</span>
              </div>
              
              {savedAssemblies.length > 0 ? (
                <div className="mt-4">
                  <ul className="space-y-2">
                    {recentAssemblies.map((assembly) => (
                      <li key={assembly.id} className="flex justify-between items-center text-sm border-b pb-2">
                        <span className="font-medium">{assembly.name}</span>
                        <span>
                          {assembly.modules.length} modules
                        </span>
                      </li>
                    ))}
                  </ul>
                </div>
              ) : (
                <div className="text-gray-500 py-4">
                  No saved assemblies yet
                </div>
              )}
              
              <div className="mt-4">
                <Link to="/saved-assemblies">
                  <Button variant="outline" className="w-full" size="sm">
                    View All
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
          
          {/* Quick Access Card */}
          <Card>
            <CardContent className="p-6">
              <h3 className="font-medium">Quick Access</h3>
              
              <div className="grid gap-2 mt-4">
                <Link to="/configurator">
                  <Button variant="outline" className="w-full justify-start" size="sm">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 10l-2 1m0 0l-2-1m2 1v2.5M20 7l-2 1m2-1l-2-1m2 1v2.5M14 4l-2-1-2 1M4 7l2-1M4 7l2 1M4 7v2.5M12 21l-2-1m2 1l2-1m-2 1v-2.5M6 18l-2-1v-2.5M18 18l2-1v-2.5" />
                    </svg>
                    Machine Configurator
                  </Button>
                </Link>
                
                <Link to="/calculator">
                  <Button variant="outline" className="w-full justify-start" size="sm">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    System Price Calculator
                  </Button>
                </Link>
                
                <Link to="/saved-assemblies">
                  <Button variant="outline" className="w-full justify-start" size="sm">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                    </svg>
                    Saved Assemblies
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
        
        {/* Features Section */}
        <div className="mt-8">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Engineering System Features</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card>
              <CardContent className="p-6">
                <div className="h-10 w-10 rounded-full bg-engineering-primary bg-opacity-10 flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-engineering-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 11V9a2 2 0 012-2m0 0V5a2 2 0 012-2h6a2 2 0 012 2v2M7 7h10" />
                  </svg>
                </div>
                <h3 className="font-medium mb-2">Modular Machine Configuration</h3>
                <p className="text-gray-500 text-sm">
                  Build and customize machines with drag-and-drop modules. Adjust quantities and see real-time cost changes.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="h-10 w-10 rounded-full bg-engineering-primary bg-opacity-10 flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-engineering-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8c-1.657 0-3 .895-3 2s1.343 2 3 2 3 .895 3 2-1.343 2-3 2m0-8c1.11 0 2.08.402 2.599 1M12 8V7m0 1v8m0 0v1m0-1c-1.11 0-2.08-.402-2.599-1M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                </div>
                <h3 className="font-medium mb-2">Financial Calculation</h3>
                <p className="text-gray-500 text-sm">
                  Precise system pricing with adjustable parameters including margins, risk factors, and currency conversion.
                </p>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="h-10 w-10 rounded-full bg-engineering-primary bg-opacity-10 flex items-center justify-center mb-4">
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-engineering-primary" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
                  </svg>
                </div>
                <h3 className="font-medium mb-2">Media Management</h3>
                <p className="text-gray-500 text-sm">
                  Upload, view, and manage images and 3D CAD models for your machine modules and assemblies.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </MainLayout>
  );
};

export default Dashboard;
