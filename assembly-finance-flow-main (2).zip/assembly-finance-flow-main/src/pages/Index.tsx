
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

// This is just a redirection page to the dashboard
const Index = () => {
  const navigate = useNavigate();
  
  useEffect(() => {
    navigate('/login', { replace: true });
  }, [navigate]);
  
  return <div>Redirecting...</div>;
};

export default Index;
