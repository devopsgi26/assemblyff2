
import React from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '@/context/AuthContext';
import LoginForm from '@/components/auth/LoginForm';

const Login: React.FC = () => {
  const { isAuthenticated } = useAuth();

  // If already authenticated, redirect to home page
  if (isAuthenticated) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gray-50 py-12 px-4 sm:px-6 lg:px-8">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <img 
            src="/lovable-uploads/5b32fd8b-8747-4e77-8d8c-b549a525e682.png" 
            alt="Obducat Logo"
            className="h-16 w-auto mx-auto mb-4"
          />
          <h2 className="mt-2 text-3xl font-bold tracking-tight text-gray-900">Engineering System</h2>
          <p className="mt-2 text-sm text-gray-600">
            Sign in to access the machine configurator and system price calculator
          </p>
        </div>
        
        <LoginForm />
      </div>
    </div>
  );
};

export default Login;
