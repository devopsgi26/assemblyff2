
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { format } from 'date-fns';
import { Card, CardHeader, CardTitle, CardDescription, CardContent, CardFooter } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from '@/components/ui/dialog';
import MainLayout from '@/components/layout/MainLayout';
import { useAssembly } from '@/context/AssemblyContext';
import { useAuth } from '@/context/AuthContext';
import { calculateSystemPrice } from '@/lib/calculations/financialCalculations';
import { formatCurrency } from '@/utils/rounding';

const SavedAssemblies: React.FC = () => {
  const { savedAssemblies, loadAssembly, deleteAssembly } = useAssembly();
  const { hasPermission } = useAuth();
  const canDelete = hasPermission('deleteAssemblies');
  const navigate = useNavigate();
  const [assemblyToDelete, setAssemblyToDelete] = useState<string | null>(null);

  const handleLoadAssembly = (assemblyId: string) => {
    loadAssembly(assemblyId);
    navigate('/calculator');
  };

  const confirmDelete = (assemblyId: string) => {
    setAssemblyToDelete(assemblyId);
  };

  const handleDeleteAssembly = () => {
    if (assemblyToDelete) {
      deleteAssembly(assemblyToDelete);
      setAssemblyToDelete(null);
    }
  };

  const cancelDelete = () => {
    setAssemblyToDelete(null);
  };

  return (
    <MainLayout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold text-gray-900">Saved Assemblies</h1>
          <Button onClick={() => navigate('/configurator')}>
            Create New Assembly
          </Button>
        </div>

        {savedAssemblies.length === 0 ? (
          <div className="border-2 border-dashed rounded-lg p-12 text-center">
            <h2 className="text-xl font-medium mb-2">No Saved Assemblies</h2>
            <p className="text-gray-500 mb-6">
              You haven't saved any machine assemblies yet.
            </p>
            <Button onClick={() => navigate('/configurator')}>
              Configure Machine
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {savedAssemblies.map((assembly) => {
              const systemPrice = calculateSystemPrice(
                assembly.modules,
                assembly.travelCosts,
                assembly.financialAdjustments
              );

              return (
                <Card key={assembly.id}>
                  <CardHeader>
                    <CardTitle>{assembly.name}</CardTitle>
                    <CardDescription>
                      Created: {format(new Date(assembly.createdAt), 'MMM d, yyyy')}
                    </CardDescription>
                  </CardHeader>
                  
                  <CardContent className="space-y-4">
                    <div>
                      <div className="text-sm text-gray-500 mb-1">Machine Specs</div>
                      <div className="text-sm">
                        <span className="font-medium">{assembly.specs.bodyType || 'No body type'}</span>
                        {assembly.specs.productLine && (
                          <span> • {assembly.specs.productLine}</span>
                        )}
                        {assembly.specs.waferSize && (
                          <span> • {assembly.specs.waferSize}</span>
                        )}
                      </div>
                    </div>
                    
                    <div>
                      <div className="text-sm text-gray-500 mb-1">Modules</div>
                      <div className="font-medium">{assembly.modules.length} modules</div>
                    </div>
                    
                    <div>
                      <div className="text-sm text-gray-500 mb-1">System Price</div>
                      <div className="text-xl font-bold text-engineering-primary">
                        {formatCurrency(systemPrice)}
                      </div>
                    </div>
                  </CardContent>
                  
                  <CardFooter className="flex gap-2">
                    <Button 
                      variant="default" 
                      className="flex-1"
                      onClick={() => handleLoadAssembly(assembly.id)}
                    >
                      Load
                    </Button>
                    {canDelete && (
                      <Button 
                        variant="destructive" 
                        onClick={() => confirmDelete(assembly.id)}
                      >
                        Delete
                      </Button>
                    )}
                  </CardFooter>
                </Card>
              );
            })}
          </div>
        )}
      </div>

      {/* Delete Confirmation Dialog */}
      <Dialog open={!!assemblyToDelete} onOpenChange={(open) => !open && cancelDelete()}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete this assembly? This action cannot be undone.
            </DialogDescription>
          </DialogHeader>
          
          <DialogFooter>
            <Button variant="outline" onClick={cancelDelete}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteAssembly}>
              Delete
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </MainLayout>
  );
};

export default SavedAssemblies;
