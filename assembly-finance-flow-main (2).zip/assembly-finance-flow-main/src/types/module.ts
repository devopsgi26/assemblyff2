
export interface ModuleData {
  id: string;
  name: string;
  description: string;
  basePrice: number; // New base price field
  costs: {
    engineering: number;
    manufacturing: number;
    bom: number;
  };
  compatibility: {
    compatibleModules: string[]; // Only module-to-module compatibility
    incompatibleModules: string[]; // Simplified compatibility system
  };
  media: {
    imageUrl?: string;
    cadModelUrl?: string;
    model3dUrl?: string;
    fileVersions?: {
      version: string;
      date: string;
      user: string;
      url: string;
      type: string;
    }[];
  };
}

export interface AssemblyModule extends ModuleData {
  quantity: number;
}

export interface MachineSpecs {
  bodyType: string;
  productLine: string;
  waferSize: string;
  chamberCount: number;
  axisSetup: string;
}

export interface TravelCost {
  personnelType: string;
  standardTime: number;
  overtimeHours: number;
  premiumTimeHours: number;
  travelTime: number;
  carExpenses: number;
  hotel: number;
  allowance: number;
}

export interface FinancialAdjustments {
  margin: number;
  bankWarranty: number;
  riskFactor: number;
  adminFees: number;
  rampUp: number;
  currencyRisk: number;
  currencyRate: number;
  warrantyPeriod?: number;
}

export interface ProcessCategoryBreakdown {
  engineering: number;
  manufacturing: number;
  bom: number;
  travel: number;
  logistics: number;
}

export interface SavedAssembly {
  id: string;
  name: string;
  createdAt: string; // ISO date string
  updatedAt: string; // ISO date string
  modules: AssemblyModule[];
  specs: MachineSpecs;
  financialAdjustments: FinancialAdjustments;
  travelCosts: TravelCost[];
}

export interface UserAction {
  actionType: string;
  userId: string;
  userName: string;
  timestamp: string; // ISO date string
  details: Record<string, any>;
}
