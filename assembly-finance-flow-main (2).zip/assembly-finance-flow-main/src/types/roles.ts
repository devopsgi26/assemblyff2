
export type UserRole = 'admin' | 'manager' | 'viewer';

export interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
}

export const rolePermissions = {
  admin: {
    canEditFinancials: true,
    canEditDefaults: true,
    canSaveAssemblies: true,
    canDeleteAssemblies: true,
    canUploadMedia: true,
  },
  manager: {
    canEditFinancials: true,
    canEditDefaults: false,
    canSaveAssemblies: true,
    canDeleteAssemblies: false,
    canUploadMedia: true,
  },
  viewer: {
    canEditFinancials: false,
    canEditDefaults: false,
    canSaveAssemblies: false,
    canDeleteAssemblies: false,
    canUploadMedia: false,
  }
};
