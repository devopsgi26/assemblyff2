
import { jsPDF } from 'jspdf';
import html2canvas from 'html2canvas';

/**
 * Exports an HTML element to a PDF document with preserved layout
 * @param elementId The ID of the element to export
 * @param filename Optional filename for the PDF (defaults to 'export')
 */
export const exportToPdf = async (elementId: string, filename: string = 'export'): Promise<void> => {
  try {
    const element = document.getElementById(elementId);
    if (!element) {
      throw new Error(`Element with ID "${elementId}" not found`);
    }

    // Add print-specific styling
    const style = document.createElement('style');
    style.textContent = `
      .pdf-export {
        background: white !important;
        color: black !important;
      }
      .pdf-export * {
        box-shadow: none !important;
        text-shadow: none !important;
      }
      .pdf-export .bg-gray-50,
      .pdf-export .bg-gray-100,
      .pdf-export .bg-gray-200 {
        background-color: #f8f9fa !important;
      }
    `;
    document.head.appendChild(style);
    
    // Add export class for styling
    element.classList.add('pdf-export');
    
    // Wait for any dynamic content to load
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const canvas = await html2canvas(element, {
      scale: 2, // Higher scale for better quality
      useCORS: true,
      allowTaint: true,
      backgroundColor: '#ffffff',
      logging: false,
      width: element.scrollWidth,
      height: element.scrollHeight,
      onclone: (clonedDoc) => {
        // Ensure all styles are preserved in the clone
        const clonedElement = clonedDoc.getElementById(elementId);
        if (clonedElement) {
          clonedElement.style.fontFamily = 'Arial, sans-serif';
          clonedElement.style.fontSize = '14px';
          clonedElement.style.lineHeight = '1.4';
        }
      }
    });
    
    // Remove temporary styling
    element.classList.remove('pdf-export');
    document.head.removeChild(style);

    const imgData = canvas.toDataURL('image/png', 1.0);
    const pdf = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4'
    });
    
    const imgWidth = 210; // A4 width in mm
    const pageHeight = 297; // A4 height in mm
    const imgHeight = canvas.height * imgWidth / canvas.width;
    
    // Add the image to the PDF with pagination if needed
    let heightLeft = imgHeight;
    let position = 0;
    
    pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
    heightLeft -= pageHeight;
    
    while(heightLeft >= 0) {
      position = heightLeft - imgHeight;
      pdf.addPage();
      pdf.addImage(imgData, 'PNG', 0, position, imgWidth, imgHeight);
      heightLeft -= pageHeight;
    }
    
    pdf.save(`${filename}_${new Date().toISOString().slice(0, 10)}.pdf`);
    return Promise.resolve();
  } catch (error) {
    console.error('PDF export failed:', error);
    return Promise.reject(error);
  }
};

/**
 * Exports HTML content as a Word document (.doc) with preserved styling
 * @param elementId The ID of the element to export
 * @param filename Optional filename for the Word document (defaults to 'export')
 */
export const exportToWord = (elementId: string, filename: string = 'export'): void => {
  try {
    const element = document.getElementById(elementId);
    if (!element) {
      throw new Error(`Element with ID "${elementId}" not found`);
    }

    // Clone the element to avoid modifying the original
    const clonedElement = element.cloneNode(true) as HTMLElement;
    
    // Apply inline styles for better Word compatibility
    const applyInlineStyles = (elem: HTMLElement) => {
      const computedStyle = window.getComputedStyle(elem);
      elem.style.fontFamily = computedStyle.fontFamily || 'Arial, sans-serif';
      elem.style.fontSize = computedStyle.fontSize || '14px';
      elem.style.color = computedStyle.color || '#000000';
      elem.style.backgroundColor = computedStyle.backgroundColor || 'transparent';
      elem.style.padding = computedStyle.padding;
      elem.style.margin = computedStyle.margin;
      elem.style.border = computedStyle.border;
      
      // Apply to all children
      Array.from(elem.children).forEach(child => {
        if (child instanceof HTMLElement) {
          applyInlineStyles(child);
        }
      });
    };
    
    applyInlineStyles(clonedElement);
    
    // Create a complete HTML document with comprehensive styles
    const htmlContent = `
      <!DOCTYPE html>
      <html xmlns:o='urn:schemas-microsoft-com:office:office' xmlns:w='urn:schemas-microsoft-com:office:word' xmlns='http://www.w3.org/TR/REC-html40'>
      <head>
        <meta charset="UTF-8">
        <title>${filename}</title>
        <style>
          @page { margin: 1in; }
          body { 
            font-family: Arial, sans-serif; 
            margin: 0; 
            padding: 20px; 
            line-height: 1.4;
            color: #000000;
            background: white;
          }
          table { 
            border-collapse: collapse; 
            width: 100%; 
            margin-bottom: 16px;
          }
          th, td { 
            border: 1px solid #ddd; 
            padding: 8px; 
            text-align: left; 
            vertical-align: top;
          }
          .font-bold, .font-semibold { font-weight: bold; }
          .text-right { text-align: right; }
          .text-center { text-align: center; }
          .border { border: 1px solid #ddd; }
          .rounded { border-radius: 4px; }
          .p-4 { padding: 16px; }
          .mb-4 { margin-bottom: 16px; }
          .space-y-2 > * + * { margin-top: 8px; }
          .grid { display: table; width: 100%; }
          .grid > div { display: table-cell; padding: 4px; }
          h1, h2, h3, h4, h5, h6 { 
            margin-top: 0; 
            margin-bottom: 12px; 
            font-weight: bold; 
          }
        </style>
      </head>
      <body>
        ${clonedElement.outerHTML}
        <div style="margin-top: 30px; font-size: 12px; color: #666; border-top: 1px solid #ddd; padding-top: 16px;">
          Generated on ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}
        </div>
      </body>
      </html>
    `;
    
    // Create a Blob with the HTML content
    const blob = new Blob([htmlContent], { 
      type: 'application/vnd.ms-word;charset=utf-8' 
    });
    const url = URL.createObjectURL(blob);
    
    // Create a link and trigger download
    const link = document.createElement('a');
    link.href = url;
    link.download = `${filename}_${new Date().toISOString().slice(0, 10)}.doc`;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    
    // Clean up
    URL.revokeObjectURL(url);
  } catch (error) {
    console.error('Word export failed:', error);
    throw error;
  }
};

/**
 * Generates HTML content for a Word document export
 * @param title Document title
 * @param sections Array of section objects with title and rows (key-value pairs)
 * @param totals Array of total rows to display at the end
 * @param options Additional options for styling and formatting
 */
export const generateExportHtml = (
  title: string,
  sections: Array<{
    title: string;
    rows: Array<{ label: string; value: string }>;
  }>,
  totals: Array<{ label: string; value: string }>,
  options?: {
    logo?: string;
    footer?: string;
    currencySymbol?: string;
  }
): string => {
  const footer = options?.footer || `Generated on ${new Date().toLocaleDateString()} at ${new Date().toLocaleTimeString()}`;
  
  return `
    <!DOCTYPE html>
    <html>
    <head>
      <meta charset="UTF-8">
      <title>${title}</title>
      <style>
        body { font-family: Arial, sans-serif; color: #333; }
        .container { max-width: 800px; margin: 0 auto; padding: 20px; }
        h1 { color: #2563eb; }
        .section { margin-bottom: 20px; }
        .section-title { font-weight: bold; margin-bottom: 10px; }
        .row { display: flex; justify-content: space-between; margin-bottom: 5px; }
        .total { font-weight: bold; border-top: 1px solid #ddd; padding-top: 5px; }
      </style>
    </head>
    <body>
      <div class="container">
        <h1>${title}</h1>
        
        ${sections.map(section => `
          <div class="section">
            <div class="section-title">${section.title}</div>
            ${section.rows.map(row => `
              <div class="row">
                <span>${row.label}</span>
                <span>${row.value}</span>
              </div>
            `).join('')}
          </div>
        `).join('')}
        
        <div class="section">
          ${totals.map((total, index) => `
            <div class="row total" style="${index === totals.length - 1 ? 'font-size: 1.2em;' : ''}">
              <span>${total.label}</span>
              <span>${total.value}</span>
            </div>
          `).join('')}
        </div>
        
        <div style="margin-top: 30px; font-size: 0.8em; color: #666;">
          ${footer}
        </div>
      </div>
    </body>
    </html>
  `;
};

/**
 * Add the required dependencies to the package for export functionality
 * @param onComplete Callback for when the dependencies are added
 */
export const ensureExportDependencies = (): Promise<void> => {
  return Promise.resolve();
};
