export const validateImageFile = (file: File): boolean => {
  const allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
  const maxSizeMB = 5;
  const maxSize = maxSizeMB * 1024 * 1024;

  if (!allowedTypes.includes(file.type)) {
    return false;
  }

  if (file.size > maxSize) {
    return false;
  }

  return true;
};

export const validateCADFile = (file: File): boolean => {
  const allowedExtensions = ['.glb', '.gltf'];
  const maxSizeMB = 20;
  const maxSize = maxSizeMB * 1024 * 1024;

  const fileExtension = file.name.slice((file.name.lastIndexOf(".") - 1 >>> 0) + 2);

  if (!allowedExtensions.includes(`.${fileExtension.toLowerCase()}`)) {
    return false;
  }

  if (file.size > maxSize) {
    return false;
  }

  return true;
};

export const createLocalFileUrl = (file: File): string => {
  return URL.createObjectURL(file);
};
