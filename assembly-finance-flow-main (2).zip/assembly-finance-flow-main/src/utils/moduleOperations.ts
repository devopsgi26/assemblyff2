
import { AssemblyModule } from '@/types/module';

// Add module to list or update quantity if it already exists
export const addOrUpdateModule = (modules: AssemblyModule[], newModule: AssemblyModule): AssemblyModule[] => {
  if (!newModule || typeof newModule !== 'object' || !newModule.id) {
    throw new Error('Invalid module data provided');
  }
  
  // Check if module already exists, if so, update quantity
  const existingModule = modules.find(m => m.id === newModule.id);
  if (existingModule) {
    return updateModuleQuantity(modules, newModule.id, existingModule.quantity + newModule.quantity);
  }
  
  // Otherwise add as new module
  return [...modules, newModule];
};

// Remove module by id
export const removeModule = (modules: AssemblyModule[], moduleId: string): AssemblyModule[] => {
  if (!moduleId) {
    throw new Error('Invalid module ID provided');
  }
  
  const moduleExists = modules.some(m => m.id === moduleId);
  if (!moduleExists) {
    throw new Error('Module not found in your assembly');
  }
  
  return modules.filter(m => m.id !== moduleId);
};

// Delete module from available modules with enhanced error handling
export const deleteAvailableModule = (modules: AssemblyModule[], moduleId: string): AssemblyModule[] => {
  if (!moduleId) {
    throw new Error('Invalid module ID provided');
  }
  
  const moduleExists = modules.some(m => m.id === moduleId);
  if (!moduleExists) {
    throw new Error('Module not found in the available modules');
  }
  
  // Create new array without the deleted module
  const updatedModules = modules.filter(m => m.id !== moduleId);
  
  // Verify the module was actually removed
  if (updatedModules.length === modules.length) {
    throw new Error('Failed to remove module from the list');
  }
  
  return updatedModules;
};

// Update module quantity
export const updateModuleQuantity = (modules: AssemblyModule[], moduleId: string, quantity: number): AssemblyModule[] => {
  if (!moduleId) {
    throw new Error('Invalid module ID provided');
  }
  
  if (quantity < 0) {
    throw new Error('Quantity cannot be negative');
  }
  
  if (quantity === 0) {
    return removeModule(modules, moduleId);
  }
  
  const moduleExists = modules.some(m => m.id === moduleId);
  if (!moduleExists) {
    throw new Error('Module not found in your assembly');
  }
  
  return modules.map(m => (m.id === moduleId ? { ...m, quantity } : m));
};

// Update module properties with enhanced validation
export const updateModule = (modules: AssemblyModule[], moduleId: string, updates: Partial<AssemblyModule>): AssemblyModule[] => {
  if (!moduleId) {
    throw new Error('Invalid module ID provided');
  }
  
  const moduleIndex = modules.findIndex(m => m.id === moduleId);
  if (moduleIndex === -1) {
    throw new Error('Module not found in your assembly');
  }
  
  const updatedModules = [...modules];
  const oldModule = updatedModules[moduleIndex];
  
  // Handle nested cost updates properly with financial precision
  if (updates.costs) {
    updates.costs = {
      engineering: Math.round((updates.costs.engineering || oldModule.costs.engineering) * 100) / 100,
      manufacturing: Math.round((updates.costs.manufacturing || oldModule.costs.manufacturing) * 100) / 100,
      bom: Math.round((updates.costs.bom || oldModule.costs.bom) * 100) / 100
    };
  }
  
  // Handle nested compatibility updates properly
  if (updates.compatibility) {
    updates.compatibility = {
      compatibleModules: updates.compatibility.compatibleModules || oldModule.compatibility?.compatibleModules || [],
      incompatibleModules: updates.compatibility.incompatibleModules || oldModule.compatibility?.incompatibleModules || []
    };
  }
  
  // Handle nested media updates properly
  if (updates.media) {
    updates.media = {
      ...oldModule.media,
      ...updates.media
    };
  }
  
  // Handle base price with financial precision
  if (typeof updates.basePrice === 'number') {
    updates.basePrice = Math.round(updates.basePrice * 100) / 100;
  }
  
  updatedModules[moduleIndex] = {
    ...oldModule,
    ...updates
  };
  
  return updatedModules;
};

// Reorder modules in the list
export const reorderModules = (modules: AssemblyModule[], sourceId: string, targetId: string): AssemblyModule[] => {
  if (!sourceId || !targetId) {
    throw new Error('Invalid module IDs provided');
  }
  
  const sourceIndex = modules.findIndex(m => m.id === sourceId);
  const targetIndex = modules.findIndex(m => m.id === targetId);
  
  if (sourceIndex === -1 || targetIndex === -1) {
    throw new Error('One or both modules not found in your assembly');
  }
  
  // Create a new array with the reordered modules
  const updatedModules = [...modules];
  const [movedModule] = updatedModules.splice(sourceIndex, 1);
  updatedModules.splice(targetIndex, 0, movedModule);
  
  return updatedModules;
};
