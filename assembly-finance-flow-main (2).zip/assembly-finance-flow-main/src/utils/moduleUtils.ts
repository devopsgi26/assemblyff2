
import { AssemblyModule } from '@/types/module';

// Calculate total costs by category for a collection of modules with financial precision
export const getCategoryCosts = (modules: AssemblyModule[]) => {
  let engineering = 0;
  let manufacturing = 0;
  let bom = 0;
  
  modules.forEach(module => {
    engineering += Math.round((module.costs.engineering * module.quantity) * 100) / 100;
    manufacturing += Math.round((module.costs.manufacturing * module.quantity) * 100) / 100;
    bom += Math.round((module.costs.bom * module.quantity) * 100) / 100;
  });
  
  return { 
    engineering: Math.round(engineering * 100) / 100, 
    manufacturing: Math.round(manufacturing * 100) / 100, 
    bom: Math.round(bom * 100) / 100 
  };
};

// Group modules by process category
export const getModulesByCategory = (modules: AssemblyModule[]) => {
  const engineering = modules.filter(module => module.costs.engineering > 0);
  const manufacturing = modules.filter(module => module.costs.manufacturing > 0);
  const bom = modules.filter(module => module.costs.bom > 0);
  
  return { engineering, manufacturing, bom };
};

// Simplified module compatibility check - only checks module-to-module compatibility
export const checkModuleCompatibility = (
  moduleToCheck: AssemblyModule, 
  existingModules: AssemblyModule[]
): boolean => {
  // If no existing modules, it's always compatible
  if (existingModules.length === 0) return true;
  
  // Ensure moduleToCheck has proper compatibility structure
  if (!moduleToCheck.compatibility) {
    return true; // If no compatibility data, assume compatible
  }
  
  const moduleIncompatibleList = moduleToCheck.compatibility.incompatibleModules || [];
  
  // Check compatibility with each existing module
  for (const existingModule of existingModules) {
    // Skip self-compatibility check
    if (existingModule.id === moduleToCheck.id) continue;
    
    // Ensure existingModule has proper compatibility structure
    if (!existingModule.compatibility) {
      continue; // If no compatibility data, assume compatible with this module
    }
    
    const existingIncompatibleList = existingModule.compatibility.incompatibleModules || [];
    
    // Check explicit incompatibility - simplified to only check incompatible lists
    if (moduleIncompatibleList.includes(existingModule.id) ||
        existingIncompatibleList.includes(moduleToCheck.id)) {
      return false;
    }
  }
  
  return true;
};

// Calculate total module price including base price with financial precision
export const calculateModulePrice = (module: AssemblyModule): number => {
  const basePrice = module.basePrice || 0;
  const totalCost = basePrice + module.costs.engineering + module.costs.manufacturing + module.costs.bom;
  return Math.round(totalCost * 100) / 100;
};

// Calculate total assembly price with financial precision
export const calculateAssemblyPrice = (modules: AssemblyModule[]): number => {
  const total = modules.reduce((sum, module) => {
    return sum + (calculateModulePrice(module) * module.quantity);
  }, 0);
  return Math.round(total * 100) / 100;
};
