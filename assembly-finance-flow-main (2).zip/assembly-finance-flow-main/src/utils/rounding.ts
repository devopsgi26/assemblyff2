
/**
 * Performs financial-grade rounding to a specified number of decimal places
 */
export const roundToDecimal = (value: number, decimals = 2): number => {
  return Number(Math.round(Number(value + 'e' + decimals)) + 'e-' + decimals);
};

/**
 * Formats a number as currency
 */
export const formatCurrency = (value: number, currency = '€', decimals = 2): string => {
  return `${currency}${value.toLocaleString('en-US', { 
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals
  })}`;
};

/**
 * Formats a number as a percentage
 */
export const formatPercent = (value: number, decimals = 2): string => {
  return `${(value * 100).toLocaleString('en-US', {
    minimumFractionDigits: decimals,
    maximumFractionDigits: decimals
  })}%`;
};

/**
 * Converts currency based on exchange rate
 */
export const convertCurrency = (value: number, exchangeRate: number): number => {
  return roundToDecimal(value * exchangeRate);
};

/**
 * Adds a percentage to a value
 */
export const addPercentage = (value: number, percentage: number): number => {
  return value * (1 + percentage);
};
